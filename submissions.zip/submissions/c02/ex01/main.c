#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern char *ft_strncpy(char *dest, char *src, unsigned int n);

int main(int argc, char **argv) {
	char exp[1000], cmp[1000], input[1000];

	char *exp_ptr = exp;
	char *cmp_ptr = cmp;

	int n;
	if (argc == 1) return 1;
	if (argc == 2) n = strlen(argv[1]);
	else n = atoi(argv[argc - 1]);

	strcpy((char*)input, argv[1]);

	
	printf("%8s | ", "index");
	for (int i = 0; i < n; i++)
		printf("%4d", i);
	printf(" | len n:%d\n", n);

	printf("%8s | ", "input");
	for (int i = 0; i < n; i++)
		printf("%4d", (int)input[i]);
	printf(" |\n\n");

	exp_ptr = ft_strncpy(exp_ptr, input, (unsigned int)n);
	cmp_ptr =    strncpy(cmp_ptr, input, (unsigned int)n);

	printf("%8s | ", "ft_str..");
	for (int i = 0; i < n; i++)
		printf("%4d", (int)exp[i]);
	printf(" | offs : %ld\n\n", exp_ptr - exp);

	printf("%8s | ", "strncpy");
	for (int i = 0; i < n; i++)
		printf("%4d", (int)cmp[i]);
	printf(" | offs : %ld\n\n", cmp_ptr - cmp);

	printf("original, return of ft_strncpy : %p, %p\n", exp, exp_ptr);
	printf("original, return of    strncpy : %p, %p\n", cmp, cmp_ptr);
}
