/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/07 18:34:07 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/07 18:34:08 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char	*dest, char	*src, unsigned int	n)
{
	unsigned int		index;

	index = 0;
	while (index < n && *(src + index))
	{
		*(dest + index) = *(src + index);
		index += 1;
	}
	while (index < n)
		*(dest + index++) = 0;
	return (dest);
}
