#include <stdio.h>
#include <string.h>

extern char *ft_strlowcase(char *str);

int	is_printable(char	str) {
	if (str < 32 || str > 126)
		return (0);
	return (1);
}

int main(int argc, char **argv) {
	char arr[100] = {'a',};
	int len = 0;
	int input;

	do {
		printf("input number (input 0 to quit)>>");
		scanf("%d", arr +len);
		len += 1;
	} while (arr[len - 1]) ;
	len--;

	/*
	while (1) {
		printf("input number [255+]to quit>>");
		scanf("%d\n", &input);
		if (input >= 255)
			break;
		arr[len++] = input;
	}
	arr[len] = 0;
	*/

	// print arr
	for (int i = 0; i < len; i++) {
		if (is_printable(arr[i]))
			printf("%4c", arr[i]);
		else 
			printf("%4d", arr[i]);
	}
	printf("\n");
	
	char *arr_ptr;
	arr_ptr = ft_strlowcase(arr);

	// print arr
	for (int i = 0; i < len; i++) {
		if (is_printable(arr[i]))
			printf("%4c", arr[i]);
		else 
			printf("%4d", arr[i]);
	}
	printf("\n");
	

	printf("\n%p %p\n", arr, arr_ptr);	


	return 0;
}

