#include <stdio.h>
#include <string.h>

extern char *ft_strcpy(char *dest, char *src);

int main(int argc, char **argv) {
	char exp[1000], com[1000];
	
	char *exp_ptr = exp;
	char *com_ptr = com;
	exp_ptr = ft_strcpy((char*)exp, argv[1]);
	com_ptr =    strcpy((char*)com, argv[1]);

	printf(" ft_strcpy : %s\n", exp_ptr);
	printf("    strcpy : %s\n", com_ptr);
}
