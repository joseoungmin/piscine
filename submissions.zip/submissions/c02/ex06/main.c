#include <stdio.h>
#include <string.h>

extern int ft_str_is_printable(char *str);

int main(int argc, char **argv) {
	char buf[1000];
	int input;
	int len = 0;
	while (1) {
		printf("input num. input 255+ to stop >>");
		scanf("%d", &input);
		if (input > 255) break;
		buf[len] = input;
		len += 1;
	} 
	for (int i = 0; i < len; i++)
		printf("%4d", buf[i]);
	printf("\n");

	for (int i = 0; i < len; i++)
		printf("%4c", buf[i]);
	printf("\n");
	printf("%d", ft_str_is_printable(buf));
}
