#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char	*ft_strcpy(char	*dest, char	*src)
{
	char	*tmp;

	tmp = dest;
	while (*src)
		*dest++ = *src++;
	*dest = *src;
	return (tmp);
}

extern unsigned int ft_strlcpy(char *dest, char *src, unsigned int size);

int main(int argc, char **argv) {
	char input[300], exp[300], cmp[300];
	int len, exp_len, cmp_len;
	ft_strcpy(input, argv[1]);
	len = atoi(argv[2]);

	printf("%8s | %s\n", "input", input);
	printf("%8s | %d\n", "len", len);

	printf("running ft_strlcpy...\n");
	exp_len = ft_strlcpy(exp, input, len);
	printf("running strlcpy...\n");
	cmp_len = strlcpy(cmp, input, len);

	printf("%8s | %s %d\n", "ft_lcpy", exp, exp_len);
	printf("%8s | %s %d\n", "strlcpy", exp, exp_len);


	argc += 1;
}
