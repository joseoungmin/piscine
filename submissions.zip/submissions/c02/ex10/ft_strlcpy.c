/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/09 18:41:12 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/15 17:40:42 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlen(char *str)
{
	unsigned int	len;

	len = 0;
	while (str[len])
		len += 1;
	return (len);
}

unsigned	int	ft_strlcpy(char	*dest, char	*src, unsigned	int	size)
{
	unsigned int	idx;
	unsigned int	len;

	idx = 0;
	len = ft_strlen(src);
	if (!dest || !src)
		return (0);
	while (idx + 1 < size && idx < size)
	{
		dest[idx] = src[idx];
		idx += 1;
	}
	if (size > 0)
		dest[idx] = 0;
	return (len);
}
