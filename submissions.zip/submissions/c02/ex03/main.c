#include <stdio.h>
#include <string.h>

extern int ft_str_is_numeric(char *str);

int main(int argc, char **argv) {
	char nullchr[2] = "";
	if (argc == 1) return 1;
	if (argc == 2) {
		printf("input:%s\n", argv[1]);
		printf("%d\n", ft_str_is_numeric(argv[1]));
	}
	if (argc == 3) {
		printf("input nullchar..\n");
		printf("%d\n", ft_str_is_numeric(nullchr));
	}
}
