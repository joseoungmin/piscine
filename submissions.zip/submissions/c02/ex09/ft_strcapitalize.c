/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/09 18:39:12 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/14 17:02:15 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	is_part_of_word(char	c)
{
	if ('0' <= c && c <= '9')
		return (1);
	if ('a' <= c && c <= 'z')
		return (1);
	if ('A' <= c && c <= 'Z')
		return (1);
	return (0);
}

char	*ft_strcapitalize(char	*str)
{
	int	flag;
	int	i;

	i = 0;
	while (str[i])
	{
		if ('A' <= str[i] && str[i] <= 'Z')
			str[i] += 32;
		i += 1;
	}
	i = 0;
	flag = 1;
	while (str[i])
	{
		if (flag && 'a' <= str[i] && str[i] <= 'z')
			str[i] -= 32;
		if (is_part_of_word(str[i]))
			flag = 0;
		else
			flag = 1;
		i += 1;
	}
	return (str);
}
