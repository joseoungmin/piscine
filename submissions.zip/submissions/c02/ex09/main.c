#include <stdio.h>

extern char *ft_strcapitalize(char	*str);

int main(int argc, char **argv) {
	if (argc != 2)
		return 1;
	printf("%s\n", argv[1]);
	printf("%p, %p\n", argv[1], ft_strcapitalize(argv[1]));
	printf("%s\n", argv[1]);
}
