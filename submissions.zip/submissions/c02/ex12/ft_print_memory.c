/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_memory.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/14 18:20:18 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/16 19:07:43 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	putchar(char	c)
{
	write(1, &c, 1);
}

void	print_char_as_hexadecimal(unsigned char c)
{
	if ((c / 16) < 10)
		putchar(c / 16 + '0');
	else
		putchar(c / 16 - 10 + 'a');
	if ((c % 16) < 10)
		putchar(c % 16 + '0');
	else
		putchar(c % 16 - 10 + 'a');
}

void	print_addr(unsigned long long addr)
{
	int				i;
	unsigned char	bytes[8];

	i = -1;
	while (++i < 8)
	{
		bytes[i] = addr % 256;
		addr /= 256;
	}
	while (--i >= 0)
		print_char_as_hexadecimal(bytes[i]);
	write(1, ": ", 2);
}

void	print_line(char	*addr, int	size)
{
	int	i;

	i = -1;
	while (++i < size)
	{
		print_char_as_hexadecimal(addr[i]);
		if (i % 2 == 1)
			write(1, " ", 1);
	}
	if (size < 16)
		write(1, "                                                            ",
			(16 - size) * 2 + (16 - size - 1) / 2 + 1);
	i = -1;
	while (++i < size)
	{
		if (addr[i] >= 32 && addr[i] <= 126)
			write(1, &(addr[i]), 1);
		else
			write(1, ".", 1);
	}
	write(1, "\n", 1);
}

void	*ft_print_memory(void	*addr, unsigned	int	size)
{
	int	i;
	int	len;

	if (size < 1 || addr == NULL)
		return (NULL);
	i = 0;
	while (size > 0)
	{
		if (size > 16)
			len = 16;
		else
			len = size;
		print_addr((unsigned long long)addr + i);
		print_line(addr + i, len);
		if (size >= 16)
		{
			size -= 16;
			i += 16;
		}
		else
			break ;
	}
	return (addr);
}
