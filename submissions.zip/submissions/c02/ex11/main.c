#include <stdio.h>
#include <string.h>

extern void ft_putstr_non_printable(char *str);

int	is_printable(char	str) {
	if (str < 32 || str > 126)
		return (0);
	return (1);
}

int main() {
	char arr[100] = {'a',};
	int len = 0;

	do {
		printf("input number (input 0 to quit)>>");
		scanf("%d", (int *)(arr + len));
		len += 1;
	} while (arr[len - 1]) ;
	len--;

	// print arr
	for (int i = 0; i < len; i++) {
		if (is_printable(arr[i]))
			printf("%c", arr[i]);
		else 
			printf("%3d", (unsigned char)arr[i]);
			//printf("%4d", arr[i]);
	}
	printf("\n");
	
	ft_putstr_non_printable(arr);

	return 0;
}

