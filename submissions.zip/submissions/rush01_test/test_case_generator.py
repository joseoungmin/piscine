import numpy as np
import time

def is_valid(board, size, cur) :
    for i in range(size) :
        if len(np.unique(board[:cur + 1, i])) < cur + 1 :
            return 0
    return 1


size = int(input("input size>>"))
col1 = [0] * size
col2 = [0] * size
row1 = [0] * size
row2 = [0] * size

board = np.array([[i for i in range(1, size+1)] for i in range(size)])

np.random.shuffle(board[0])
i = 1

while (i < size) :
    np.random.shuffle(board[i]);
    while not is_valid(board, size, i) :
        np.random.shuffle(board[i]);
    i += 1

for i in range(size) :
    max = 0
    for j in range(size) :
        if max < board[i, j] :
            col1[i] += 1
            max = board[i, j]

for i in range(size) :
    max = 0
    for j in range(size - 1, -1, -1) :
        if max < board[i, j] :
            col2[i] += 1
            max = board[i, j]

for i in range(size) :
    max = 0
    for j in range(size) :
        if max < board[j, i] :
            row1[i] += 1
            max = board[j, i]

for i in range(size) :
    max = 0
    for j in range(size - 1, -1, -1) :
        if max < board[j, i] :
            row2[i] += 1
            max = board[j, i]

print("    ",end="")
for i in range(size) :
    print("%d "%row1[i], end="")
print()
print("   -", end="")
for i in range(size) :
    print("--", end="")
print()
for i in range(size) :
    print("%d | "%col1[i], end="")
    for j in range(size) :
        print("%d "%board[i, j], end="")
    print("| %d"%col2[i])
print("   -", end="")
for i in range(size) :
    print("--", end="")
print()
print("    ",end="")
for i in range(size) :
    print("%d "%row2[i], end="")
