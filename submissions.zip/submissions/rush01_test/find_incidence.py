cases = {}

def print_dict(dic) :
    for k, v in dic.items() :
        print(k, ":")
        for val in v :
            print("  ", val)

def print_array(arr, rows, cols) :
    print("------------")
    for i in range(rows) :
        for j in range(cols) :
            print(arr[i][j], end = " ")
        print()
    print("-------------")
    print()

def classify_cases(printed, idx, size) :
    for i in range(1, size + 1) :
        if i not in printed[:idx] :
            printed[idx] = i
            if idx == size - 1 :
                visibles = how_many_visibles(printed, size)
                if visibles in cases :
                    cases[visibles].append([printed[j] for j in range(size)])
                else :
                    cases[visibles] = [[printed[j] for j in range(size)]]
                return
            else :
                classify_cases(printed, idx + 1, size)

def how_many_visibles(arr, size) :
    visible = [0, 0]
    max = 0
    for i in range(size) :
        if arr[i] > max :
            visible[0] += 1;
            max = arr[i]
    max = 0;
    for i in range(size-1, -1, -1) :
        if arr[i] > max :
            visible[1] += 1;
            max = arr[i]
    return visible[0] * 10 + visible[1]

def is_valid(arr, size, idx) :
    for i in range(size) :
        for j in range(idx) :
            num = arr[j][i]
            for k in range(j + 1, idx + 1) :
                if arr[k][i] == num :
                    return 0
    return 1

def compose_array(arr, candidate, idx, h_visibles, v_visibles) :
    for i in range(idx + 1) :
        arr[i] = cases[v_visibles[i]][candidate[i]]

def check_and_fill(candidate, arr, size, idx, h_visibles, v_visibles) :
    for i in range(len(cases[v_visibles[idx]])) :
        candidate[idx] = i
        compose_array(arr, candidate, idx, h_visibles, v_visibles)
        if is_valid(arr, size, idx) :
            print_array(arr, idx, size)
            if idx == size - 1:
                print("found!!")
                print_array(arr, size, size)
                return
            check_and_fill(candidate, arr, size, idx + 1, h_visibles, v_visibles)


size = int(input("input size >> "))
combination = [0] * size;
classify_cases(combination, 0, size);

#print_dict(cases)

v_visibles = [0] * size
h_visibles = [0] * size

for i in range(size) :
    x = int(input("enter col1 - %d:"%(i + 1)))
    v_visibles[i] = x * 10;
for i in range(size) :
    x = int(input("enter col2 - %d:"%(i + 1)))
    v_visibles[i] += x

for i in range(size) :
    x = int(input("enter row1 - %d:"%(i + 1)))
    h_visibles[i] = x * 10;
for i in range(size) :
    x = int(input("enter row2 - %d:"%(i + 1)))
    h_visibles[i] += x


candidate = [0] * size
arr = [[0 for i in range(size)] for i in range(size)]
check_and_fill(candidate, arr, size, 0, h_visibles, v_visibles)
