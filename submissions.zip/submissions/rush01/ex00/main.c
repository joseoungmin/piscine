#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>

int	g_comb_num_t[10][10];
int	*g_comb_ref_t[10][10];
int	g_comb_idx_t[10][10];
int	g_row_idxs[2][10];
int	g_board[9][9];

void	initialize_tables(int	size);
void	solve(int	*v_visibles, int	size, int	idx, int	*count);

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	print_g_board(int	size)
{
	int i;
	int	j;

	i = 0;
	while (i < size)
	{
		j = 0;
		while (j < size)
		{
			ft_putchar(g_board[i][j] + '0');
			ft_putchar(' ');
		}
		ft_putchar('\n');
	}
}

int		is_white_space(char c)
{
	return (c == ' ' || (9 <= c && c <= 13) || c == 0);
}

int	is_valid_input(char	*string, int	*vals)
{
	int	i;

	i = 0;

	while (*string)
	{
		if (!(is_white_space(*(string + 1)) && '1' <= *string && *string <= '9'))
			return (0);
		vals[i++] = *string - '0';
		printf("%d\n")
		if (*(string + 1) == 0)
			return (i);
		string += 2;
	}
	return (i);
}


int	main(int	argc, char	**argv)
{
	int	size;
	int	count;
	int	visibles[36];
	int	*v_visibles;
	int i;

	if (argc != 2)
	{
		write(1, "Error\n", 6);
		return (1);
	}
	count = 0;
	size = is_valid_input(argv[1], visibles);
	if (size == 0 || size % 4 != 0)
	{
		write(1, "Error\n", 6);
		return (1);
	}

	printf("size : %d\n", size);
	for (int j = 0; j < size; j++)
		printf("%d ", visibles[j]);

	size /= 4;

	i = 0;
	while (i < size)
	{
		v_visibles[i] = visibles[i] * 10;
		v_visibles[i] += visibles[i + size];
		g_row_idxs[1][i] = visibles[i + 2 * size] * 10;
		g_row_idxs[1][i] += visibles[i + 3 * size];
	}

	initialize_tables(size);
	solve(v_visibles, size, 0, &count);
	if (count == 0)
	{
		write(1, "Error\n", 6);
		return (1);
	}
	print_g_board(size);
}