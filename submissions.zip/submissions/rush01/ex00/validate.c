
void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int		is_white_space(char c)
{
	return (c == ' ' || (9 <= c && c <= 13));
}
