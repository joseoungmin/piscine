int	num_visible_buildings(int	*arr, int	size)
{
	int	visibles;
	int	i;
	int	max1;
	int	max2;

	visibles = 0;
	i = -1;
	max1 = 0;
	max2 = 0;
	while (++i < size)
	{
		if (arr[i] > max1)
		{
			visibles += 10;
			max1 = arr[i];
		}
		if (arr[size - i - 1] > max2)
		{
			visibles += 1;
			max2 = arr[size - i - 1];
		}
	}
	return (visibles);
}

int	val_is_not_in_arr(int	*arr, int	size, int	val)
{
	int	i;

	i = 0;
	while (i < size)
	{
		if (arr[i] == val)
			return (0);
		i += 1;
	}
	return (1);
}