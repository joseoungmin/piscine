#include <stdlib.h>

extern int	g_comb_num_t[10][10];
extern int	*g_comb_ref_t[10][10];
extern int	g_comb_idx_t[10][10];

int	num_visible_buildings(int	*arr, int	size);

int	val_is_not_in_arr(int	*arr, int	size, int	val);

// hight :  hight is 1 ~ size = size of board
void	set_row_comb_num_table(int	*row, int	size, int	idx)
{
	int	i;
	int	visibles;

	i = 1;
	while (i <= size)
	{
		if (val_is_not_in_arr(row, idx, i))
		{
			row[idx] = i;
			if (idx == size - 1)
			{
				visibles = num_visible_buildings(row, size);
				g_comb_num_t[visibles / 10][visibles % 10] += 1;
				return ;
			}
			set_row_comb_num_table(row, size, idx + 1);
		}
		i += 1;
	}
}

void	allocate_row_comb_memory(int	size)
{
	int	i;
	int	j;

	i = 0;
	while (++i <= size)
	{
		j = 0;
		while (++j <= size)
		{
			g_comb_ref_t[i][j] = (int *)
				malloc(sizeof(int) * g_comb_num_t[i][j]);
		}
	}
}

int	compress_to_int(int	*row, int	size)
{
	int	result;
	int	idx;
	int	scale;

	idx = size;
	scale = 1;
	result = 0;
	while (--idx >= 0)
	{
		result += row[idx] * scale;
		scale *= 10;
	}
	return (result);
}

void	store_row_comb(int	*row, int	size, int	idx)
{
	int	i;
	int	v;

	i = 1;
	while (i <= size)
	{
		if (val_is_not_in_arr(row, idx, i))
		{
			row[idx] = i;
			if (idx == size - 1)
			{
				v = num_visible_buildings(row, size);
				g_comb_ref_t[v / 10][v % 10][g_comb_idx_t[v / 10][v % 10]]
					= compress_to_int(row, size);
				g_comb_idx_t[v / 10][v % 10] += 1;
				return ;
			}
			store_row_comb(row, size, idx + 1);
		}
		i += 1;
	}
}

void	initialize_tables(int	size)
{
	int	row[10];

	set_row_comb_num_table(row, size, 0);
	allocate_row_comb_memory(size);
	store_row_comb(row, size, 0);
}
