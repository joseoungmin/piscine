#include <stdio.h>

int		is_white_space(char c)
{
	return (c == ' ' || (9 <= c && c <= 13) || c == 0);
}

int	is_valid_input(char	*string, int	*vals)
{
	int	i;

	i = 0;

	while (*string)
	{
		if (!(is_white_space(*(string + 1)) && '1' <= *string && *string <= '9'))
			return (0);
		vals[i++] = *string - '0';
		if (*(string + 1) == 0)
			return (i);
		string += 2;
	}
	return (i);
}


int main(int argc, char **argv) {
	int arr[36];
	int size = is_valid_input(argv[1], arr);
	printf("size : %d\n", size);
	
	printf("\n");
	for (int i = 0; i < 10; i++) {
		printf("%d ", arr[i]);
	}
}