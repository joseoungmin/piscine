// gcc test/solver_tester.c test/test_utils.c initialize.c utils.c  

#include <stdio.h>
#include <stdlib.h>

int	g_comb_num_t[10][10];
int	*g_comb_ref_t[10][10];
int	g_comb_idx_t[10][10];
int	g_row_idxs[2][10];
int	g_board[9][9];

void print_g_board(int size, int idx);
void print_g_comb_num_t(int size);
void print_combinations(int size);
void print_g_row_idxs(int size);
void	initialize_tables(int	size);

extern int	num_visible_buildings(int	*arr, int	size);



int	col_elems_are_unique(int	size, int	idx)
{
	int	i;
	int	j;
	int	k;

	i = 0;
	while (i < size)
	{
		j = 0;
		while (j <= idx - 1)
		{
			k = j + 1;
			while (k < idx)
			{
				if (g_board[k][i] == g_board[j][i])
					return (0);
				k++;
			}
			j++;
		}
		i++;
	}
	return (1);
}

void	compose_board(int	size, int	idx)
{
	int i;
	int	num;

	i = size;
	num = g_comb_ref_t[g_row_idxs[1][idx] / 10][g_row_idxs[1][idx] % 10][g_row_idxs[0][idx]];
	while (--i >= 0)
	{
		g_board[idx][i] = num % 10;
		num /= 10;
	}
}

int	cols_are_valid(int	size, int	*v_visibles)
{
	int	i;
	int j;
	int	*arr;

	i = 0;
	arr = (int *)malloc(sizeof(int) * size);
	while (i < size)
	{
		j = -1;
		while (++j < size)
			arr[j] = g_board[j][i];
		
/*
		print_g_board(size, size - 1);

		printf("\narr : ");
		for (int k = 0; k < size; k++)
			printf("%d ", arr[k]);
		printf("\n");
		
		printf("v_visibiles : ");
		for (int k = 0; k < size; k++)
			printf("%d ", v_visibles[k]);
		printf("\n");
		printf("num_visible : %d\n\n\n", num_visible_buildings(arr, size));	
*/

		if (num_visible_buildings(arr, size) != v_visibles[i])
			return (0);
		i += 1;
	}


	return (1);
}

void	solve(int	*v_visibles, int	size, int	idx, int	*count)
{
	int	i;

	if (*count)
		i = 1;
			//return ;
	i = 0;
	while (i < g_comb_num_t[g_row_idxs[1][idx] / 10]
		[g_row_idxs[1][idx] % 10])
	{
		g_row_idxs[0][idx] = i;
		compose_board(size, idx);
		if (col_elems_are_unique(size, idx))
		{
			if (idx == size - 1)
			{
				if (cols_are_valid(size, v_visibles)) {
					printf("found -------\n");
					print_g_board(size, size - 1);
					*count += 1;
					return;
				}
			}
			if (idx < size - 1)
				solve(v_visibles, size, idx + 1, count);
		}
		i += 1;
	}	
}

int main(int argc, char **argv) {
	int	size;
	int	count;

	count = 0;

	printf("size >>");
	scanf("%d", &size);

	printf("size : %d\n", size);	
	int *v_visibles = (int*)malloc(sizeof(int) * size);

	for (int i = 0; i < size; i++) {
		printf("enter col visibles [%d / %d] >>", i + 1, size);
		scanf("%d", &(g_row_idxs[1][i]));
	}

	for (int i = 0; i < size; i++) {
		printf("enter row visibles [%d / %d] >>", i + 1, size);
		scanf("%d", &(v_visibles[i]));
	}


	initialize_tables(size);


	solve(v_visibles, size, 0, &count);

	printf("\ncount : %d\n", count);



}