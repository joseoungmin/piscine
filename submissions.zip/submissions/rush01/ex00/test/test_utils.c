#include <stdio.h>

extern int	g_comb_num_t[10][10];
extern int	*g_comb_ref_t[10][10];
extern int	g_comb_idx_t[10][10];
extern int	g_row_idxs[2][10];
extern int	g_board[9][9];

void print_g_board(int size, int idx);
void print_g_comb_num_t(int size);
void print_combinations(int size);
void print_g_row_idxs(int size);


void print_g_board(int size, int idx)
{
	printf("board:\n");

	for (int i = 0; i <= idx; i++) {
		for (int j = 0; j < size; j++) {
			printf("%d ", g_board[i][j]);
		}
		printf("\n");
	}
}

void print_g_comb_num_t(int size)
{
	printf("g_comb_num_t :\n");
	for (int i = 0; i < size + 1; i++) {
		for (int j = 0; j < size + 1; j++)
			printf("%4d ", g_comb_num_t[i][j]);
		printf("\n\n\n");
	}
}


void print_combinations(int size)
{
	for (int i = 1; i <= size; i++) {
		for (int j = 1; j <= size; j++) {
			printf("%d:-> %d <-:%d\n\t\t", i, g_comb_num_t[i][j], j);
			for (int k = 0; k < g_comb_num_t[i][j]; k++)
				printf("%d  ", g_comb_ref_t[i][j][k]);
			printf("\n\n");
		}
	}
}

void print_g_row_idxs(int size) {
	printf("g_row_idxs : \n");
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < size; j++)
			printf("%d ", g_row_idxs[i][j]);
		printf("\n");
	} printf("\n");
}