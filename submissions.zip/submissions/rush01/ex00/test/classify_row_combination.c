#include <stdio.h>
#include <stdlib.h>

extern int	g_row_comb_num_table[10][10];
extern int	*g_row_comb_ref_table[10][10];

int	num_visible_buildings(int	*arr, int	size)
{
	int	visibles;
	int	i;
	int	max1;
	int	max2;

	visibles = 0;
	i = -1;
	max1 = 0;
	max2 = 0;
	while (++i < size)
	{
		if (arr[i] > max1)
		{
			visibles += 10;
			max1 = arr[i];
		}
		if (arr[size - i - 1] > max2)
		{
			visibles += 1;
			max2 = arr[size - i - 1];
		}
	}
	return (visibles);
}

int	val_is_not_in_arr(int	*arr, int	size, int	val)
{
	int	i;

	i = 0;
	while (i < size)
	{
		if (arr[i] == val)
			return (0);
		i += 1;
	}
	return (1);
}

void	set_row_comb_num_table(int	*rows, int	size, int	idx)
{
	int	i;
	int	visibles;

	i = 1;
	while (i <= size)
	{
		if (val_is_not_in_arr(rows, idx, i))
		{
			rows[idx] = i;
			if (idx == size - 1)
			{
				visibles = num_visible_buildings(rows, size);
				g_row_comb_num_table[visibles / 10][visibles % 10] += 1;
				return ;
			}
			set_row_comb_num_table(rows, size, idx + 1);
		}
		i += 1;
	}
}

void	find_cases(int	*rows, int	size, int	idx)
{
	int	 i;

	i = 1;
	while (i <= size)
	{
		if (val_is_not_in_arr(rows, idx, i))
		{
			rows[idx] = i;
			if (idx == size - 1)
			{
				return ;
			}
			find_cases(rows, size, idx + 1);
		}
		i += 1;
	}
}

int main(int argc, char ** argv)
{
	int row[10];
	int size;

	size = atoi(argv[1]);
	set_row_comb_num_table(row, size, 0);
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size; j++)
			printf("%4d ", g_row_comb_num_table[i][j]);
		printf("\n\n\n");
	}	
}
