//gcc test/test_utils.c test/compose_board_tester.c initialize.c utils.c   


#include <stdio.h>
#include <stdlib.h>

void	initialize_tables(int	size);

int	g_comb_num_t[10][10];
int	*g_comb_ref_t[10][10];
int	g_comb_idx_t[10][10];
int	g_row_idxs[2][10];
int	g_board[9][9];


void	compose_board(int	size, int	idx)
{
	int i;
	int	num;

	i = size;
	num = g_comb_ref_t[g_row_idxs[1][idx] / 10][g_row_idxs[1][idx] % 10][g_row_idxs[0][idx]];
	while (--i >= 0)
	{
		g_board[idx][i] = num % 10;
		num /= 10;
	}
}

void print_combinations(int size);

void print_g_comb_num_t(int size);

void print_g_board(int size, int idx);

int main(int argc, char **argv)
{
	int size = atoi(argv[1]);
	initialize_tables(size);

	print_g_comb_num_t(size);
	print_combinations(size);

	g_row_idxs[1][0] = 32;
	g_row_idxs[0][0] = 4;



	compose_board(size, 0);

	print_g_board(size, 0);
}