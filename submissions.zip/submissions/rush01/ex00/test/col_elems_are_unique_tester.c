#include <stdio.h>

int	g_board[9][9] = {
	{1, 2, 3, 4, 5, 6, 7, 8, 9},
	{3, 1, 2, 5, 6, 8, 9, 7, 5},
	{2, 4, 5, 1, 6, 7, 8, 9, 3},
	{9, 5, 4, 3, 2, 8, 6, 1, 7},
};

int	col_elems_are_unique(int	size, int	idx)
{
	int	i;
	int	j;
	int	k;

	i = 0;
	while (i < size)
	{
		j = 0;
		while (j < idx - 1)
		{
			k = j + 1;
			while (k < idx)
			{
				if (g_board[k][i] == g_board[j][i])
					return (0);
				k++;
			}
			j++;
		}
		i++;
	}
	return (1);
}

int main() {
	printf("%d\n", col_elems_are_unique(9, 2));
}