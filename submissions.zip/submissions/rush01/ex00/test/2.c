#include <stdio.h>
#include <stdlib.h>

int	num_visible_buildings(int	*arr, int	size)
{
	int	visibles;
	int	i;
	int	max1;
	int	max2;

	visibles = 0;
	i = -1;
	max1 = 0;
	max2 = 0;
	while (++i < size)
	{
		if (arr[i] > max1)
		{
			visibles += 10;
			max1 = arr[i];
		}
		if (arr[size - i - 1] > max2)
		{
			visibles += 1;
			max2 = arr[size - i - 1];
		}
	}
	return (visibles);
}

int	compress_to_int(int	*rows, int	size)
{
	int result;
	int idx;
	int	scale;

	idx = size;
	scale = 1;
	result = 0;
	while (--idx >= 0)
	{
		result += rows[idx] * scale;
		scale *= 10;
	}
	return (result);
}

//compress_to_int tester
int main(int argc, char ** argv)
{
	int row[10];
	for (int i = 0; i < argc - 1; i++) {
		row[i] = atoi(argv[i + 1]);
		printf("%d ", row[i]);
	}
	printf("\n%d\n", compress_to_int(row, argc - 1));
}

/*
//num_visible_buildings  tester
int main(int argc, char ** argv)
{
	int row[10];
	for (int i = 0; i < argc - 1; i++) {
		row[i] = atoi(argv[i + 1]);
		printf("%d ", row[i]);
	}
	printf("\n%d\n", num_visible_buildings(row, argc - 1));
}
*/