#include <stdlib.h>

extern int	g_comb_num_t[10][10];
extern int	*g_comb_ref_t[10][10];
extern int	g_comb_idx_t[10][10];
extern int	g_row_idxs[2][10];
extern int	g_board[9][9];

extern int	num_visible_buildings(int	*arr, int	size);

int	col_elems_are_unique(int	size, int	idx)
{
	int	i;
	int	j;
	int	k;

	i = 0;
	while (i < size)
	{
		j = 0;
		while (j <= idx - 1)
		{
			k = j + 1;
			while (k < idx)
			{
				if (g_board[k][i] == g_board[j][i])
					return (0);
				k++;
			}
			j++;
		}
		i++;
	}
	return (1);
}

int	cols_are_valid(int	size, int	*v_visibles)
{
	int	i;
	int j;
	int	*arr;

	i = 0;
	arr = (int *)malloc(sizeof(int) * size);
	while (i < size)
	{
		j = -1;
		while (++j < size)
			arr[j] = g_board[j][i];
		if (num_visible_buildings(arr, size) != v_visibles[i])
			return (0);
		i += 1;
	}
	return (1);
}

void	compose_board(int	size, int	idx)
{
	int i;
	int	num;

	i = size;
	num = g_comb_ref_t[g_row_idxs[1][idx] / 10][g_row_idxs[1][idx] % 10][g_row_idxs[0][idx]];
	while (--i >= 0)
	{
		g_board[idx][i] = num % 10;
		num /= 10;
	}
}

void	solve(int	*v_visibles, int	size, int	idx, int	*count)
{
	int	i;

	if (*count)
		i = 1;
			return ;
	i = 0;
	while (i < g_comb_num_t[g_row_idxs[1][idx] / 10]
		[g_row_idxs[1][idx] % 10])
	{
		g_row_idxs[0][idx] = i;
		compose_board(size, idx);
		if (col_elems_are_unique(size, idx))
		{
			if (idx == size - 1)
			{
				if (cols_are_valid(size, v_visibles)) {
					*count += 1;
					return;
				}
			}
			if (idx < size - 1)
				solve(v_visibles, size, idx + 1, count);
		}
		i += 1;
	}	
}