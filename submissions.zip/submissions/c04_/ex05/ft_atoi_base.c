/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/15 14:26:00 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/15 18:00:09 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	is_valid_base(char	*base)
{
	int		len;
	char	cache[256];

	len = -1;
	while (++len < 256)
		cache[len] = 0;
	len = -1;
	while (base[++len])
	{
		if (cache[(int)base[len]])
			return (0);
		cache[(int)base[len]] = 1;
		if (base[len] == '-' || base[len] == '+'
			|| base[len] == ' ' || base[len] == '\n'
			|| base[len] == '\t' || base[len] == '\v'
			|| base[len] == '\f' || base[len] == '\r')
			return (0);
	}
	return (len);
}

int	where_is_char(char	c, char	*str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] == c)
			return (i);
		i += 1;
	}
	return (-1);
}

long long	as_decimal(char	*str, char	*base, int	base_len)
{
	long long	n;
	int			char_val;

	n = 0;
	char_val = where_is_char(*str, base);
	while (char_val >= 0)
	{
		n *= base_len;
		n += char_val;
		str += 1;
		char_val = where_is_char(*str, base);
	}
	return (n);
}

int	ft_atoi_base(char	*str, char	*base)
{
	int			base_len;
	int			s;

	base_len = is_valid_base(base);
	if (base_len < 2)
		return (0);
	s = 1;
	while (*str == '\t'
		|| *str == '\n'
		|| *str == '\v'
		|| *str == '\f'
		|| *str == '\r'
		|| *str == ' ')
		++str;
	while (*str == '+' || *str == '-')
		if (*(str++) == '-')
			s *= -1;
	return (s * as_decimal(str, base, base_len));
}
