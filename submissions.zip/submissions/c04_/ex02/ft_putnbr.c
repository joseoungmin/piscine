/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/12 13:56:19 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/12 13:57:33 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	long	i;
	int		u;

	i = nb;
	if (i < 0)
	{
		ft_putchar('-');
		i = -i;
	}
	if (i > 9)
	{
		ft_putnbr(i / 10);
		u = i % 10;
		ft_putchar(u + '0');
	}
	else
		ft_putchar(i + '0');
}
