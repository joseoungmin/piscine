#include <stdio.h>
#include <stdlib.h>

void	ft_putnbr_base(int	nbr, char	*base);

int main(int argc, char **argv) {
	if (argc != 3)
		return -1;
	int num = atoi(argv[1]);
	ft_putnbr_base(num, argv[2]);
}
