/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/14 14:24:01 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/15 14:37:56 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	is_valid_base(char	*base)
{
	int		len;
	char	cache[256];

	len = -1;
	while (++len < 256)
		cache[len] = 0;
	len = -1;
	while (base[++len])
	{
		if (cache[(int)base[len]])
			return (0);
		cache[(int)base[len]] = 1;
		if (base[len] == '-' || base[len] == '+')
			return (0);
	}
	return (len);
}

void	print_changed_base(long long	n, char	*base, int	base_len)
{
	if (n < base_len)
	{
		write(1, &(base[n]), 1);
		return ;
	}
	print_changed_base(n / base_len, base, base_len);
	write(1, &(base[n % base_len]), 1);
}

void	ft_putnbr_base(int	nbr, char	*base)
{
	int			base_len;
	long long	n;

	n = nbr;
	base_len = is_valid_base(base);
	if (base_len < 2)
		return ;
	if (nbr < 0)
	{
		write(1, "-", 1);
		n *= -1;
	}
	print_changed_base(n, base, base_len);
}
