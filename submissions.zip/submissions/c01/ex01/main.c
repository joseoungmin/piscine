#include <stdio.h>
#include <stdlib.h>

extern void ft_ultimate_ft(int *********nbr);

int main(int argc, char** argv) {
	int num = atoi(argv[1]);
	int *num_1;
	int **num_2;
	int ***num_3;
	int ****num_4;
	int *****num_5;
	int ******num_6;
	int *******num_7;
	int ********num_8;
	int *********num_9;
	num_1 = &num;
	num_2 = &num_1;
	num_3 = &num_2;
	num_4 = &num_3;
	num_5 = &num_4;
	num_6 = &num_5;
	num_7 = &num_6;
	num_8 = &num_7;
	num_9 = &num_8;

	printf("input : %d\n", *********num_9);
	ft_ultimate_ft(num_9);
	printf("moded : %d\n", *********num_9);
}
