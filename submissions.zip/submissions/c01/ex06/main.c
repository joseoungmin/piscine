#include <stdio.h>
#include <string.h>

int ft_strlen(char *str);

int main(int argc, char** argv) {
	char buf[1000];

	strcpy(buf, argv[1]);

	printf("input : \n%s\n", buf);
	printf("len : %d\n", strlen(buf));
	printf("len : %d\n",ft_strlen(buf));
}
