#include <stdio.h>
#include <stdlib.h>

extern void ft_ft(int *nbr);

int main(int argc, char **argv) {
	int num = atoi(argv[1]);
	printf("input : %d\n", num);

	ft_ft(&num);
	printf("moded : %d\n", num);
}
