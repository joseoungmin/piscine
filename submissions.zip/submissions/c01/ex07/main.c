#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

extern void ft_rev_int_tab(int *tab, int size);

int main(int argc, char **argv) {
	int arr[100];
	int len = 0;

	for (int i = 0; i < argc -  1; i++) {
		arr[i] = atoi(argv[i + 1]);
		len++;
	}

	for (int i = 0; i < len; i++) {
		printf("%-4d ", arr[i]);
	} printf("\n\n");

	ft_rev_int_tab(arr, len);

	for (int i = 0; i < len; i++) {
		printf("%-4d ", arr[i]);
	} printf("\n\n");

	ft_rev_int_tab(arr, len);

	for (int i = 0; i < len; i++) {
		printf("%-4d ", arr[i]);
	} printf("\n\n");
}
