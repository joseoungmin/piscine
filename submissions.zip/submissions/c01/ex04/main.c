#include <stdlib.h>
#include <stdio.h>

extern void ft_ultimate_div_mod(int *a, int *b);

int main(int argc, char **argv) {
	int a = atoi(argv[1]);
	int b = atoi(argv[2]);

	int *a_ptr = &a;
	int *b_ptr = &b;
	printf("intput : %d %d\n", *a_ptr, *b_ptr);

	ft_ultimate_div_mod(a_ptr, b_ptr);

	printf("moded : %d %d\n", *a_ptr, *b_ptr);
}
