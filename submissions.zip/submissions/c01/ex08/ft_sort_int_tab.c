/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/07 15:19:15 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/07 17:18:49 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	swap(int	*a, int	*b)
{
	int	tmp;

	tmp = *a;
	*a = *b;
	*b = tmp;
}

void	quick_sort(int	*arr, int	start, int	end)
{
	int	pivot;
	int	s_idx;
	int b_idx;

	if (start >= end)
		return ;
	pivot = *(arr + start);
	s_idx = start + 1;
	b_idx = end;
	while (s_idx < b_idx)
	{
		if (arr[s_idx] <= pivot)
			s_idx += 1;
		else if (arr[b_idx] >= pivot)
			b_idx -= 1;
		if (arr[s_idx] >= pivot && arr[b_idx] <= pivot)
			swap(arr + s_idx, arr + b_idx);
	}
	if (arr[start] > arr[s_idx])
		swap(arr + start, arr + s_idx);
	quick_sort(arr, start, s_idx - 1);
	quick_sort(arr, s_idx, end);
}

void	ft_sort_int_tab(int	*tab, int	size)
{
	quick_sort(tab, 0, size - 1);
}
