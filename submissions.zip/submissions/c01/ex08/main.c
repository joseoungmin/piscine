#include <stdlib.h>
#include <stdio.h>

void ft_sort_int_tab(int *tab, int size);

int main(int argc, char **argv) {
	int arr[100];
	int len = 0;	

	for (int i = 0; i < argc -1; i++) {
		arr[i] = atoi(argv[i + 1]);
		len += 1;
	}

	printf("\n");
	printf("input | ");
	for (int i = 0; i < len; i++)
		printf("%4d ", arr[i]);
	printf("\n\n");
	
	ft_sort_int_tab(arr, len);

	printf("output| ");
	for (int i = 0; i < len; i++)
		printf("%4d ", arr[i]);
	printf("\n\n");
}
