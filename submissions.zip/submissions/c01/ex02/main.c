#include <stdlib.h>
#include <stdio.h>

extern void ft_swap(int *a, int *b);

int main(int argc, char** argv)
{
	int a, b;
	int *a_ptr = &a;
	int *b_ptr = &b;
	*a_ptr = atoi(argv[1]);
	*b_ptr = atoi(argv[2]);

	printf("input : %d %d\n", *a_ptr, *b_ptr);
	
	ft_swap(a_ptr, b_ptr);

	printf("moded : %d %d\n", *a_ptr, *b_ptr);
}
