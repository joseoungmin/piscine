#include <stdio.h>
#include <stdlib.h>

extern void ft_div_mod(int a, int b, int *div, int *mod);

int main(int argc, char** argv)
{
	int a, b;
	int div, mod;
	int *div_ptr = &div;
	int *mod_ptr = &mod;

	a = atoi(argv[1]);
	b = atoi(argv[2]);

	ft_div_mod(a, b, div_ptr, mod_ptr);

	printf("%d %d\n", *div_ptr, *mod_ptr);
}
