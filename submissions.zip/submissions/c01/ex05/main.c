#include <stdio.h>
#include <string.h>

extern void ft_putstr(char *str);

int main(int argc, char** argv) {
	char buf[1000];

	strcpy(buf, argv[1]);

	printf("input : \n%s\n", buf);
	ft_putstr(buf);
}
