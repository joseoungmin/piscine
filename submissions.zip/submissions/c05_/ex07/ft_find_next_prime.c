/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/10 15:21:46 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/17 10:24:40 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_prime(int	nb)
{
	long long	divider;

	if (nb < 2)
		return (0);
	if (nb == 2)
		return (1);
	if (nb == 3)
		return (1);
	if (nb % 2 == 0)
		return (0);
	if (nb % 3 == 0)
		return (0);
	divider = 5;
	while (divider * divider <= nb)
	{
		if (nb % divider == 0)
			return (0);
		divider += 1;
	}
	return (1);
}

int	ft_find_next_prime(int	nb)
{
	while (!ft_is_prime(nb))
		nb += 1;
	return (nb);
}
