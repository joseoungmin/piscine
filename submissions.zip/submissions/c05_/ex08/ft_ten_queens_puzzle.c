/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ten_queens_puzzle.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/10 15:33:43 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/15 19:00:33 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_board(int	*board, int	size)
{
	int		i;
	char	c;

	i = 0;
	while (i < size)
	{
		c = '0' + board[i];
		write(1, &c, 1);
		i++;
	}
	write(1, "\n", 1);
}

int	is_valid(int	*board, int	idx)
{
	int	row;

	row = 0;
	while (row < idx)
	{
		if (board[row] == board[idx])
			return (0);
		if (board[row] - board[idx] == row - idx)
			return (0);
		if (board[row] - board[idx] == idx - row)
			return (0);
		row += 1;
	}
	return (1);
}

void	ten_queens_base(int	*board, int	size, int	idx, int	*count)
{
	int	pos;

	pos = 0;
	while (pos < size)
	{
		board[idx] = pos;
		if (is_valid(board, idx))
		{
			if (idx == size - 1)
			{
				print_board(board, size);
				*count += 1;
				return ;
			}
			else
				ten_queens_base(board, size, idx + 1, count);
		}
		pos += 1;
	}
}

int	ft_ten_queens_puzzle(void)
{
	int	board[10];
	int	count;

	count = 0;
	ten_queens_base(board, 10, 0, &count);
	return (count);
}
