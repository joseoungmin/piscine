/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ten_queens_puzzle.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/10 15:33:43 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/17 12:40:49 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

#include <stdio.h>

void print_board(int	*board, int	size)
{
	for (int i = 0; i < size; i++)
		printf("%d", board[i]);
	printf("\n");
	return;
	
	int 	i;
	char	c;

	i = 0;
	while (i < size)
	{
		c = '0' + board[i];
		write(1, &c, 1);
		i++;
		write(1, "\n", 1);
	}
}

void draw_board(int	*board, int size)
{
	printf("-");
	for (int i = 0; i < size; i++)
		printf("----");
	printf("\n");
	for (int i = 0; i < size; i++) {
		printf("|");
		for (int j = 0; j < size; j++) {
			if (board[i] == j)
				printf(" o |");
			else
				printf("   |");
		}
		printf(" %d\n", board[i]);
		printf("-");
		for (int i = 0; i < size; i++)
			printf("----");
		printf("\n");
	}
	printf("\n");
}

int	is_valid(int	*board, int	idx)
{
	int row;

	row = 0;
	while (row < idx) {
		if (board[row] == board[idx])
			return (0);
		if (board[row] - board[idx] == row - idx)
			return (0);
		if (board[row] - board[idx] == idx - row)
			return (0);
		row += 1;
	}
	return 1;
}

void	ten_queens_base(int	*board, int	size, int	idx, int	*count)
{
	int	pos;

	pos = 0;
	while (pos < size) {
		board[idx] = pos;
		if (is_valid(board, idx)) {
			if (idx == size - 1) {
				print_board(board, size);
				draw_board(board, size);
				*count += 1;
				return;
			}
			else 
				ten_queens_base(board, size, idx + 1, count);
		}
		pos += 1;
	}
}

int	ft_ten_queens_puzzle(void)
{
	int board[13];
	int count;

	count = 0;
	ten_queens_base(board, 10, 0, &count);
	return (count);
}

int main() {
	printf("\n%d\n",ft_ten_queens_puzzle());
}
