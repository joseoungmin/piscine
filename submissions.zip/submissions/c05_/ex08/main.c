#include <stdio.h>

int ft_ten_queens_puzzle(void);

int main() {
	ft_ten_queens_puzzle();
}
