#include <stdio.h>
#include <stdlib.h>

int ft_recursive_power(int nb, int power);

int main(int argc, char **argv) {
	int num = atoi(argv[1]);
	int pow = atoi(argv[2]);
	printf("%d\n", ft_recursive_power(num, pow));
	argc += 1;
}
