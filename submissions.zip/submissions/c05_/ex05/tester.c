#include <stdio.h>
int ft_sqrt(int nb);
int main(void) {
        printf("sqrt of %d is %d\n", -3396, ft_sqrt(-3396));
        printf("sqrt of %d is %d\n", 0, ft_sqrt(0));
        printf("sqrt of %d is %d\n", 1, ft_sqrt(1));
        printf("sqrt of %d is %d\n", 2, ft_sqrt(2));
        printf("sqrt of %d is %d\n", 1640045925, ft_sqrt(1640045925));
        printf("sqrt of %d is %d\n", 2147395600, ft_sqrt(2147395600));
        printf("sqrt of %d is %d\n", 2147483646, ft_sqrt(2147483646));
        printf("sqrt of %d is %d\n", 915970225, ft_sqrt(915970225));
        printf("sqrt of %d is %d\n", 1860860472, ft_sqrt(1860860472));
        printf("sqrt of %d is %d\n", 2130191716, ft_sqrt(2130191716));
        printf("sqrt of %d is %d\n", 891670441, ft_sqrt(891670441));
        printf("sqrt of %d is %d\n", 354230041, ft_sqrt(354230041));
        printf("sqrt of %d is %d\n", 1232920507, ft_sqrt(1232920507));
        printf("sqrt of %d is %d\n", 94595076, ft_sqrt(94595076));
        printf("sqrt of %d is %d\n", 1094862901, ft_sqrt(1094862901));
        printf("sqrt of %d is %d\n", 295049329, ft_sqrt(295049329));
        printf("sqrt of %d is %d\n", 735486517, ft_sqrt(735486517));
}
