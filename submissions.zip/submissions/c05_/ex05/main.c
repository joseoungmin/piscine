#include <stdio.h>
#include <stdlib.h>

int ft_sqrt(int nb);

int main(int argc, char **argv) {
	int num = atoi(argv[1]);
	printf("%d\n", ft_sqrt(num));
	argc += 1;
}
