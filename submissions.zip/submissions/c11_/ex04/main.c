#include <stdio.h>
#include <stdlib.h>

int	intcmp(int	a, int	b) {
	return a - b;
}

int	ft_is_sort(int	*tab, int	length, int	(*f)(int, int));

int main(int argc, char **argv) {
	
	if (argc < 2)
		return 1;
	
	int *arr = (int *)malloc(sizeof(int) * argc - 1);

	for (int i = 1; i < argc; i++) {
		arr[i] = atoi(argv[i]);
	}

	

	printf("%d\n", ft_is_sort());
}