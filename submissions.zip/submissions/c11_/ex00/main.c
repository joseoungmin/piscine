#include <stdio.h>
#include <unistd.h>

void	ft_putnbr(int nb)
{
	long long	n;
	char		c;

	n = nb;
	if (n < 0)
	{
		write(1, "-", 1);
		n = -n;
	}
	if (n / 10 > 0)
		ft_putnbr(n / 10);
	c = n % 10 + '0';
	write(1, &c, 1);
}
void	ft_foreach(int	*tab, int	length, void	(*f)(int));

int main()
{
	int 	tab[10];

	for (int i = 0; i < 10; i++)
		tab[i] = i * i;

	ft_foreach(tab, 10, &ft_putnbr);
	
}