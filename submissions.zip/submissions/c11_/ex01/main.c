#include <stdio.h>
#include <unistd.h>

int		*ft_map(int	*tab, int	length, int (*f)(int));
void	ft_foreach(int	*tab, int	length, void	(*f)(int))
{
	int	i;

	i = 0;
	while (i < length)
		f(tab[i++]);
}

int sq(int n) {
	return n * n;
}

int main()
{
	int 	tab[10];

	for (int i = 0; i < 10; i++)
		tab[i] = i * i;

	int *rets = ft_map(tab, 10, &sq);

	for (int i = 0; i < 10; i++)
		printf("%d ", rets[i]);
}