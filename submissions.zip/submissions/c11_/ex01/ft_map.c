/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/21 14:24:48 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/21 14:24:51 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_map(int	*tab, int	length, int	(*f)(int))
{
	int	*ret;
	int	i;

	ret = (int *)malloc(sizeof(int) * length);
	if (ret == NULL)
		return (0);
	i = -1;
	while (++i < length)
		ret[i] = f(tab[i]);
	return (ret);
}
