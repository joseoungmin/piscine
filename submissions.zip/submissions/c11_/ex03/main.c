#include <stdio.h>
#include <stdlib.h>

int	is_even_length(char *str)
{
	int len = 0;
	while (str[len])
		len++;
	if (len % 2)
		return 0;
	else
		return 1;
}

int	ft_count_if(char	**tab, int	length, int (*f)(char *));

int main(int argc, char **argv) {
	printf("%d\n", ft_count_if(argv, argc, &is_even_length));
}