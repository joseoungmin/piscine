#include <stdio.h>
#include <stdlib.h>

int	is_even_length(char *str)
{
	int len = 0;
	while (str[len])
		len++;
	if (len % 2)
		return 0;
	else
		return 1;
}

int ft_any(char **tab, int (*f)(char*));

int main(int argc, char **argv) {
	if (argc < 2)
		return 1;

	for (int i = 0; i < argc; i++)
		printf("%s ", argv[i]);
	printf("\n");

	printf("%d\n", ft_any(argv, &is_even_length));
	

}