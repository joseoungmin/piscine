#include <stdio.h>

char	**ft_split(char	*str, char	*charset);

int main(int argc, char	**argv)
{
	if (argc != 3)
		return -1;
	char	**splited = ft_split(argv[1], argv[2]);

	int i = 0;
	while(splited[i])
	{
		printf("%s\n", splited[i]);
		i += 1;
	}
}