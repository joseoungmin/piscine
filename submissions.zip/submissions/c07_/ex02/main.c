#include <stdio.h>
#include <stdlib.h>

int	ft_ultimate_range(int	**range, int	min, int max);

int main(int argc, char **argv) {
	printf("main.\n");
	int min = atoi(argv[1]);
	int max = atoi(argv[2]);

	printf("min : %d, max : %d, ", min, max);
	
	int *arr;
	int size = ft_ultimate_range(&arr, min, max);
	printf("size : %d\n", size);


	printf("arr ->  ");
	for (int i = 0; i < size; i++)
		printf("%d ", arr[i]);

	printf("\n");
	argc += 1;
}
