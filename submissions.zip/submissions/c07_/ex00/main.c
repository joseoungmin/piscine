#include <stdio.h>
#include <stdlib.h>

char *ft_strdup(char *str);

int main(int argc, char **argv) {

	char *a = "askl;dfhaskldfhaksdfjasdfj";

	printf("%p %s\n", a, a);

	if (argc == 2) {
		char *dest = ft_strdup(argv[1]);
		printf("string from %p : %s\n", dest, dest);
	} else if (argc == 3) {
		char *dest = ft_strdup(argv[1]);
		int len = atoi(argv[2]);
		printf("idx | ");
		for (int i = 0; i < len; i++)
			printf("%4d", i);
		printf("\n");
		printf("val | ");
		for (int i = 0; i < len; i++)
			printf("%4c", dest[i]);
		printf("\n");
		printf("val | ");
		for (int i = 0; i < len; i++)
			printf("%4d", dest[i]);
		printf("\n");
	}	
}
