/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/16 10:05:24 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/21 14:32:21 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>

unsigned long long	ft_strlen(char	*str)
{
	unsigned long long	len;

	len = 0;
	while (str[len])
		len += 1;
	return (len);
}

char	*ft_strdup(char *src)
{
	long long	len;
	char		*dest;

	len = ft_strlen(src);
	dest = (char *)malloc(sizeof(char) * (len + 1));
	dest[len] = 0;
	while (--len >= 0)
		dest[len] = src[len];
	return (dest);
}
