#include <stdio.h>
#include <stdlib.h>

int	*ft_range(int	min, int	max);

int	main(int argc, char **argv) {
	if (argc == 3) {
		int min = atoi(argv[1]);
		int max = atoi(argv[2]);
		int *arr = ft_range(min, max);

		for (int i = 0; i < ( max > min ? (max - min) : 0 ); i++)
			printf("%6d", arr[i]);
		printf("\n");
	}

	else if (argc == 4) {
		int min = atoi(argv[1]);
		int max = atoi(argv[2]);
		int len = atoi(argv[3]);

		int *arr = ft_range(min, max);

		for (int i = 0; i < len; i++)
			printf("%6d", arr[i]);
		printf("\n");
	}
}
