#include <stdio.h>

char	*ft_convert_base(char	*nbr, char	*base_from, char	*base_to);
long long	ib2ll(char	*nbr, char	*ibase, int	ibase_len);
int	is_valid_base(char *base);

int main(int argc, char **argv) {
	if (argc != 4)
		return -1;
	/*printf("nbr       =>%s<=\n", argv[1]);
	printf("base_from =>%s<=\n", argv[2]);
	printf("base_to   =>%s<=\n", argv[3]);
	printf("\n");
	printf("ib2ll     =>%lld<=\n", ib2ll(argv[1], argv[2], is_valid_base(argv[2])));
	printf("\n");
	printf("result    =>%s<=\n", ft_convert_base(argv[1], argv[2], argv[3]));
	*/

	printf("%s\n", ft_convert_base(argv[1], argv[2], argv[3]));
	
	int ibase_len = is_valid_base(argv[2]);
	int obase_len = is_valid_base(argv[3]);
	
	printf("\n\n     echo \"obase=%d; ibase=%d; %s \" | bc      \n", obase_len, ibase_len, argv[1]);

}
