#include <stdio.h>
#include <string.h>

char	*ft_strjoin(int	size, char	**strs, char	*sep);

int main(int	argc, char	**argv)
{
	char seperator[100];
	if (argc < 3)
		strcpy(seperator, " ");
	else
		strcpy(seperator, argv[argc - 1]);
	
	char *seperated = ft_strjoin(argc - 2, &(argv[1]), seperator);
	
	for (int i = 1; i < (argc < 3 ? argc : argc - 1); i++) {
		printf("strs[%d] : >%s<\n", i - 1, argv[i]);
	}
	printf("\n");
	printf("sep : >%s<", seperator);
	printf("\n\n");
	printf("%s", seperated);

	//printf("\n%d %d\n", seperated[0], seperated[1]);
}
