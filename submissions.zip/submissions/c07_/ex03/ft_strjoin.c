/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/17 13:48:58 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/21 14:40:47 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

#include <stdio.h>

long long	stlen(char	*str)
{
	long long	len;

	len = 0;
	while (str[len])
		len += 1;
	return (len);
}

void	ft_strcat(char	*dest, char *src)
{
	while (*dest)
		dest++;
	while (*src)
		*dest++ = *src++;
}

char	*ft_strjoin(int	size, char	**strs, char	*sep)
{
	long long	len;
	int			i;
	char		*str;

	len = 0;
	i = -1;
	if (!size)
	{
		str = (char *)malloc(sizeof(char));
		str[0] = 0;
		return (str);
	}
	while (++i < size)
		len += stlen(strs[i]);
	str = (char *)malloc(sizeof(char) * (len + (size - 1) * stlen(sep) + 1));
	i = -1;
	while (++i < size)
	{
		ft_strcat(str, strs[i]);
		if (i < size - 1)
			ft_strcat(str, sep);
	}
	str[len + (size - 1) * stlen(sep)] = 0;
	return (str);
}
