
extern void	ft_putchar(char	c);

int main(int argc, char** argv)
{
	char a = argv[1][0];
	ft_putchar(a);
}

