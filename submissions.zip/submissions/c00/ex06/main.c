extern void ft_print_comb2(void);

int main() {
	ft_print_comb2();
}
