/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/06 20:33:22 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/07 20:28:49 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	delimitate(void)
{
	char	delimiter[3];

	delimiter[0] = ',';
	delimiter[1] = ' ';
	write(1, delimiter, 2);
}

void	print(int	num1, int	num2)
{
	char	digits[6];

	digits[0] = num1 / 10 + '0';
	digits[1] = num1 % 10 + '0';
	digits[2] = ' ';
	digits[3] = num2 / 10 + '0';
	digits[4] = num2 % 10 + '0';
	write(1, digits, 5);
}

void	ft_print_comb2(void)
{
	int		num1;
	int		num2;

	num1 = 0;
	num2 = 1;
	while (-1)
	{
		print(num1, num2);
		num2 += 1;
		if (num2 == 100)
		{
			num1 += 1;
			if (num1 == 99)
			{
				break ;
			}
			num2 = num1 + 1;
		}
		delimitate();
	}
}
