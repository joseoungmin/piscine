/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/06 20:48:53 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/07 14:32:00 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_digit(char	*digits, int	n)
{
	int		index;
	char	buf[10];

	index = 0;
	while (index < n)
	{
		buf[index] = digits[index] + '0';
		index += 1;
	}
	write(1, buf, n);
}

void	delimitate(void)
{
	char	delimiter[3];

	delimiter[0] = ',';
	delimiter[1] = ' ';
	write(1, delimiter, 2);
}

void	initialize(char	*digits, int	n)
{
	int	index;

	index = 0;
	while (index < n)
	{
		digits[index] = index;
		index += 1;
	}
}

int	get_break_point(char	*digits, int n)
{
	int	index;

	index = n - 1;
	while (digits[index] >= 10 - n + index)
	{
		index -= 1;
		if (index < 0)
			break ;
	}
	return (index);
}

void	ft_print_combn(int	n)
{
	char	digits[10];
	int		index;

	initialize(digits, n);
	while (1)
	{
		print_digit(digits, n);
		index = get_break_point(digits, n);
		if (index < 0)
			return ;
		else if (index == n - 1)
			digits[index] += 1;
		else
		{
			digits[index] += 1;
			while (index < n - 1)
			{
				digits[index + 1] = digits[index] + 1;
				index += 1;
			}
		}
		delimitate();
	}
}
