#include <stdlib.h>

extern void ft_print_combn(int n);

int main(int argc, char**argv) {
	int a = atoi(argv[1]);
	ft_print_combn(a);
}
