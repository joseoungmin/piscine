extern void	ft_print_comb(void);
extern void delimitate(void);

int main() {
	ft_print_comb();
}
