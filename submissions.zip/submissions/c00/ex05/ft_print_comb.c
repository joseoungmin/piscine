/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42.student.42seoul.kr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/03 13:37:13 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/07 20:23:32 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_digit(int num)
{
	char	a;

	a = '0' + num;
	write(1, &a, 1);
}

void	delimitate(void)
{
	char	delimiter[3];

	delimiter[0] = ',';
	delimiter[1] = ' ';
	write(1, delimiter, 1);
	write(1, delimiter + 1, 1);
}

void	print_num(int num)
{
	print_digit(num / 100);
	print_digit((num % 100) / 10);
	print_digit(num % 10);
}

void	print_n_delimitate(int	num)
{	
	print_num(num);
	if (num < 789)
		delimitate();
}

void	ft_print_comb(void)
{
	int	num;
	int	tmp;

	num = 12;
	while (1)
	{
		print_n_delimitate(num);
		if (num % 10 == 9)
		{
			if (num % 100 >= 80)
			{
				if (num % 1000 >= 700)
					break ;
				tmp = num / 100 + 1;
				num = tmp * 100 + (tmp + 1) * 10 + tmp + 2;
			}
			else
			{
				tmp = (num % 100) / 10 + 1;
				num = num + 1 + tmp + 1;
			}
		}
		else
			num += 1;
	}
}
