#include <stdlib.h>

extern void ft_is_negative(int n);

int main(int argc, char **argv) {
	int a = atoi(argv[1]);
	ft_is_negative(a);
}

	
