#include <string.h>
#include <stdlib.h>
#include <stdio.h>

extern void ft_putnbr(int nb);

int main(int argc, char** argv) {
	int a = atoi(argv[1]);
	printf("input : %d\n", a);
	ft_putnbr(a);
}
