/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/06 20:48:35 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/07 20:36:15 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#define INT_MIN -2147483648

void	handle_intmin(void)
{
	char	chp[12];

	chp[0] = '-';
	chp[1] = '2';
	chp[2] = '1';
	chp[3] = '4';
	chp[4] = '7';
	chp[5] = '4';
	chp[6] = '8';
	chp[7] = '3';
	chp[8] = '6';
	chp[9] = '4';
	chp[10] = '8';
	chp[11] = 0;
	write(1, chp, 11);
}

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	if (nb < 0)
	{
		/*if (nb == INT_MIN)
		{
			handle_intmin();
			return ;
		}*/
		ft_putchar('-');
		nb = -nb;
	}
	if (nb / 10 > 0)
		ft_putnbr(nb / 10);
	ft_putchar(nb % 10 + '0');
}
