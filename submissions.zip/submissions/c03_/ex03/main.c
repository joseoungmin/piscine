#include <string.h>
#include <stdio.h>
#include <stdlib.h>

char *ft_strncat(char *dest, char *src, int nb);

int main(int argc, char **argv)
{
	char exp[300], cmp[300];
	char *exp_ptr, *cmp_ptr;
	unsigned int len = 0;
	strcpy(exp, argv[1]);
	strcpy(cmp, argv[1]);
	len = atoi(argv[3]);
	printf(" exp | %s\n", exp);
	printf(" cmp | %s\n", cmp);
	printf(" len | %d\n", len);
	
	printf("concatenating to exp...\n");
	exp_ptr = ft_strncat(exp, argv[2], len);	
	printf("concatenating to cmp...\n");
	cmp_ptr =    strncat(cmp, argv[2], len);

	printf(" exp | %s\n", exp);
	printf(" cmp | %s\n", cmp);

	printf(" %p %p \n", exp, exp_ptr);
	printf(" %p %p \n", cmp, cmp_ptr);
}
