/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/09 16:23:36 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/09 17:57:58 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char	*dest, char	*src, unsigned int	nb)
{
	char			*dest_ptr;
	unsigned int	i;

	dest_ptr = dest;
	i = 0;
	while (*dest)
		dest++;
	while (*src && i++ < nb)
		*dest++ = *src++;
	*dest = 0;
	return (dest_ptr);
}
