#include <string.h>
#include <stdio.h>

char *ft_strcat(char *dest, char *src);

int main(int argc, char **argv)
{
	char exp[300], cmp[300];
	char *exp_ptr, *cmp_ptr;
	strcpy(exp, argv[1]);
	strcpy(cmp, argv[1]);
	printf(" exp | %s\n", exp);
	printf(" cmp | %s\n", cmp);
	
	printf("concatenating to exp...\n");
	exp_ptr = ft_strcat(exp, argv[2]);	
	printf("concatenating to cmp...\n");
	cmp_ptr = strcat(cmp, argv[2]);

	printf(" exp | %s\n", exp);
	printf(" cmp | %s\n", cmp);

	printf(" %p %p \n", exp, exp_ptr);
	printf(" %p %p \n", cmp, cmp_ptr);
}
