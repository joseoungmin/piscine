#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int  ft_strncmp(char *s1, char *s2, unsigned int n);

int main(int argc, char** argv) {
	unsigned int len = (unsigned int)atoi(argv[3]);
	printf("   argv[1] | %s\n", argv[1]);
	printf("   argv[2] | %s\n", argv[2]);
	printf("    length | %d\n",  len);
	
	printf("   strcpmp : %d\n",    strncmp(argv[1], argv[2], len));
	printf(" ft_strcmp : %d\n", ft_strncmp(argv[1], argv[2], len));
}	
