#include <string.h>
#include <stdio.h>

char *ft_strstr(char *str, char *to_find);

int main(int argc, char **argv) {
	printf("haystack  | %s\n", argv[1]);
	printf("needle    | %s\n", argv[2]);
	
	char *ptr1, *ptr2;

	ptr1 = ft_strstr(argv[1], argv[2]);
	ptr2 =    strstr(argv[1], argv[2]);

	printf("ft_strstr | %p %s\n", ptr1, ptr1);
	printf("strstr 	  | %p %s\n", ptr1, ptr2);
}
