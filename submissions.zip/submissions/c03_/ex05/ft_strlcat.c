/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/09 18:21:27 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/09 18:21:29 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcat(char	*dest, char	*src, unsigned int	size)
{
	unsigned int	len1;
	unsigned int	len2;
	unsigned int	i;

	len1 = 0;
	len2 = 0;
	i = 0;
	while (dest[len1])
		len1++;
	while (src[len2])
		len2++;
	if (len1 >= size)
		return (len2 + size);
	while (i < size - len1 - 1 && src[i])
	{
		dest[len1 + i] = src[i];
		i += 1;
	}
	dest[len1 + i] = 0;
	return (len1 + len2);
}
