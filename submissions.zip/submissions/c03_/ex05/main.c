#include <stdio.h>
#include <string.h>
#include <stdlib.h>

unsigned int ft_strlcat(char *dest, char *src, unsigned int size);

int main(int argc, char **argv) {
	int len = atoi(argv[3]);
	char exp[300], cmp[300];

	strcpy(exp, argv[1]);
	strcpy(cmp, argv[1]);

	printf(" argv[1] | %s\n", argv[1]);
	printf(" argv[2] | %s\n", argv[2]);
	printf("    size | %d\n", len);
	printf("\n");

	int result_exp = ft_strlcat(exp, argv[2], (unsigned int)len);
	int result_cmp =    strlcat(cmp, argv[2], (unsigned int)len);
	
	printf("ft_strlcat>>%s<<%d\n", exp, result_exp);
	printf("   strlcat>>%s<<%d\n", cmp, result_cmp);
}
