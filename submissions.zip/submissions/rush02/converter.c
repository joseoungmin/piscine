/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   converter.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/20 20:48:19 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/20 20:48:25 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "t_entry.h"
#include "util.h"

int	search(t_entry	**entries, unsigned int	key, char	***buf)
{
	while (*entries)
	{
		if ((*entries)->key == key)
		{
			*buf = (*entries)->val;
			return (1);
		}
		entries++;
	}
	*buf = 0;
	return (0);
}

void	join_n_print(char	**buf, int	space)
{
	int	i;
	int	j;

	i = 0;
	if (space)
		write(1, " ", 1);
	while (buf[i] != 0)
	{
		j = 0;
		while (buf[i][j] != 0)
		{
			write(1, &(buf[i][j]), 1);
			j++;
		}
		if (buf[i + 1] != 0)
			write(1, " ", 1);
		i += 1;
	}
}

void	convert_base(unsigned int	n, int	scale,
	t_entry	**entries, int	*printed)
{
	char	**buf;
	int		i;
	int		num;

	if (n)
	{
		search(entries, n, &buf);
		join_n_print(buf, *printed);
		*printed = 1;
	}	
	if (scale)
	{
		num = 1;
		i = -1;
		while (++i < scale)
			num *= 10;
		search(entries, num, &buf);
		join_n_print(buf, *printed);
		*printed = 1;
	}
}

void	convert(unsigned int	num, int	scale,
		t_entry	**entries, int *printed)
{
	if (num > 999)
		convert(num / 1000, scale + 3, entries, printed);
	if (num % 1000 / 100)
		convert_base(num % 1000 / 100, 2, entries, printed);
	if (num % 100 / 10)
	{
		if (num % 100 / 10 == 1)
			convert_base(num % 100, 0, entries, printed);
		else
			convert_base(num % 100 / 10 * 10, 0, entries, printed);
	}
	if (num % 100 / 10 != 1 && num % 10)
		convert_base(num % 10, 0, entries, printed);
	if (scale && num % 1000)
		convert_base(0, scale, entries, printed);
}
