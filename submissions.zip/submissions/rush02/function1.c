#include <unistd.h>
#include <stdlib.h>
#include "t_entry.h"

int			ft_atoi(char *str);
char		**ft_split(char *str, char *charset);
void		ft_putnbr(unsigned int n);
void		join_n_print(char	**buf, int	space);
void		convert(unsigned int	num, int	scale,
				t_entry	**entries, int *printed);
int			search(t_entry	**entries, unsigned int	key, char	***buf);
int			check_arg_num(int argc);
long long	check_key(int argc, char **argv);
int			set_fd(char *file_name, int *fd);
long long	check_arg(int argc, char **argv);
int			close_fd(int fd);
int			find_zero(int fd, char *tmp);
int			print_zero(char	*file_name, int col_len);
int			set_lengths(char *file_name, int *entry_size, int *max_str);
t_entry		**alloc_entry(char *file_name, int *entry_size, int *max_str);
int			alloc_arr(char **tmp, int max_str);
t_entry		*initialize_entry(unsigned int *key, char ***val);
int			parse(unsigned int *key, char ***val, char *tmp);
void		read_parse(int fd, char **val, char *tmp, t_entry **entry_arr);
int			fill_entry(char *file_name,
				t_entry **entry_arr, int *max_str, char **val);
int			set_entry(char *file_name, t_entry **entry_arr, int *max_str);
void		free_entry(t_entry **entry_arr);
t_entry		**get_entry(int argc, char **argv, int *entry_size, int *max_len);
int			init_arg(int argc, char **argv, long long *input);
int			main(int argc, char**argv);
void		get_file_name(int argc, char **argv, char *name);

int	fill_entry(char *file_name, t_entry **entry_arr, int *max_str, char **val)
{
	int		fd;
	char	*tmp;

	if (set_fd(file_name, &fd) == -1)
		return (0);
	if (!alloc_arr(&tmp, *max_str))
	{
		close(fd);
		return (0);
	}
	read_parse(fd, val, tmp, entry_arr);
	free(tmp);
	return (close_fd(fd));
}

int	set_entry(char *file_name, t_entry **entry_arr, int *max_str)
{
	char	**val;

	val = (char **)malloc(sizeof(char *) * (*max_str / 2 + 1));
	if (val == 0)
		return (0);
	val[*max_str / 2] = 0;
	if (!fill_entry(file_name, entry_arr, max_str, val))
	{
		free(val);
		return (0);
	}
	free(val);
	return (1);
}

t_entry	**get_entry(int argc, char **argv, int *entry_size, int *max_len)
{
	t_entry	**entry_arr;
	int		max_str;
	char	*file_name;

	max_str = 0;
	if (argc == 2)
		file_name = "numbers.dict";
	else
		file_name = *(argv + 1);
	entry_arr = alloc_entry(file_name, entry_size, &max_str);
	if (entry_arr == 0)
		return (0);
	if (!set_entry(file_name, entry_arr, &max_str))
	{
		free_entry(entry_arr);
		return (0);
	}
	*max_len = max_str;
	return (entry_arr);
}

int	init_arg(int argc, char **argv, long long *input)
{
	*input = check_arg(argc, argv);
	if (*input == -1)
	{
		write(1, "Error\n", 6);
		return (0);
	}
	return (1);
}
