#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include "t_entry.h"

int			ft_atoi(char *str);
char		**ft_split(char *str, char *charset);
void		ft_putnbr(unsigned int n);
void		join_n_print(char	**buf, int	space);
void		convert(unsigned int	num, int	scale,
				t_entry	**entries, int *printed);
int			search(t_entry	**entries, unsigned int	key, char	***buf);
int			check_arg_num(int argc);
long long	check_key(int argc, char **argv);
int			set_fd(char *file_name, int *fd);
long long	check_arg(int argc, char **argv);
int			close_fd(int fd);
int			find_zero(int fd, char *tmp);
int			print_zero(int argc, char **argv, int col_len);
int			set_lengths(char *file_name, int *entry_size, int *max_str);
t_entry		**alloc_entry(char *file_name, int *entry_size, int *max_str);
int			alloc_arr(char **tmp, int max_str);
t_entry		*initialize_entry(unsigned int *key, char ***val);
int			parse(unsigned int *key, char ***val, char *tmp);
void		read_parse(int fd, char **val, char *tmp, t_entry **entry_arr);
int			fill_entry(char *file_name,
				t_entry **entry_arr, int *max_str, char **val);
int			set_entry(char *file_name, t_entry **entry_arr, int *max_str);
void		free_entry(t_entry **entry_arr);
t_entry		**get_entry(int argc, char **argv, int *entry_size, int *max_len);
int			init_arg(int argc, char **argv, long long *input);
int			main(int argc, char**argv);
void		get_file_name(int argc, char **argv, char *name);

int	set_fd(char *file_name, int *fd)
{
	*fd = open(file_name, O_RDONLY);
	return (*fd);
}

long long	check_arg(int argc, char **argv)
{
	long long	nbr;

	if (!check_arg_num(argc))
		return (-1);
	nbr = check_key(argc, argv);
	if (nbr == -1)
		return (-1);
	return (nbr);
}

int	close_fd(int fd)
{
	if (close(fd) < 0)
		return (0);
	return (1);
}

int	find_zero(int fd, char *tmp)
{
	char	buf[1];
	int		i;

	i = 0;
	while (read(fd, buf, 1) == 1)
	{
		tmp[i] = buf[0];
		if (buf[0] == '\n')
		{
			tmp[i] = 0;
			i = ft_atoi(tmp);
			if (i == 0)
			{
				while (*tmp != ':')
					tmp++;
				tmp++;
				join_n_print(ft_split(tmp, " \n"), 0);
				return (1);
			}
			i = 0;
		}
		i++;
	}
	return (0);
}

int	print_zero(int argc, char **argv, int col_len)
{
	int		fd;
	char	*tmp;
	int		ret;
	char	name[1000];

	if (argc == 2)
		fd = open("numbers.dict", O_RDONLY);
	else
	{
		get_file_name(argc, argv, name);
		fd = open(name, O_RDONLY);
	}
	if (fd == -1)
		return (0);
	tmp = (char *)malloc(sizeof(char) * (col_len + 1));
	ret = find_zero(fd, tmp);
	free(tmp);
	close(fd);
	return (ret);
}
