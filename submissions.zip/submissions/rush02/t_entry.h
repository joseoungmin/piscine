/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   t_entry.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/20 20:49:05 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/20 20:49:07 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef T_ENTRY_H
# define T_ENTRY_H

typedef struct t_entry {
	unsigned int	key;
	char			**val;
}	t_entry;

#endif
