#include <unistd.h>
#include <stdlib.h>
#include "t_entry.h"

int			ft_atoi(char *str);
char		**ft_split(char *str, char *charset);
void		ft_putnbr(unsigned int n);
void		join_n_print(char	**buf, int	space);
void		convert(unsigned int	num, int	scale,
				t_entry	**entries, int *printed);
int			search(t_entry	**entries, unsigned int	key, char	***buf);
int			check_arg_num(int argc);
long long	check_key(int argc, char **argv);
int			set_fd(char *file_name, int *fd);
long long	check_arg(int argc, char **argv);
int			close_fd(int fd);
int			find_zero(int fd, char *tmp);
int			print_zero(char	*file_name, int col_len);
int			set_lengths(char *file_name, int *entry_size, int *max_str);
t_entry		**alloc_entry(char *file_name, int *entry_size, int *max_str);
int			alloc_arr(char **tmp, int max_str);
t_entry		*initialize_entry(unsigned int *key, char ***val);
int			parse(unsigned int *key, char ***val, char *tmp);
void		read_parse(int fd, char **val, char *tmp, t_entry **entry_arr);
int			fill_entry(char *file_name,
				t_entry **entry_arr, int *max_str, char **val);
int			set_entry(char *file_name, t_entry **entry_arr, int *max_str);
void		free_entry(t_entry **entry_arr);
t_entry		**get_entry(int argc, char **argv, int *entry_size, int *max_len);
int			init_arg(int argc, char **argv, long long *input);
int			main(int argc, char**argv);
void		get_file_name(int argc, char **argv, char *name);

int	set_lengths(char *file_name, int *entry_size, int *max_str)
{
	int		fd;
	char	buf[1];
	int		str_len;

	str_len = 0;
	if (set_fd(file_name, &fd) == -1)
		return (0);
	while (read(fd, buf, 1) == 1)
	{
		if (buf[0] == '\n')
		{
			(*entry_size)++;
			if (str_len > *max_str)
				*max_str = str_len;
			str_len = 0;
		}
		else
			str_len++;
	}
	return (close_fd(fd));
}

t_entry	**alloc_entry(char *file_name, int *entry_size, int *max_str)
{
	t_entry	**entries;

	if (!set_lengths(file_name, entry_size, max_str) || *entry_size == 0)
		return (0);
	entries = (t_entry **)malloc(sizeof(t_entry *) * (*entry_size + 1));
	if (entries == 0)
		return (0);
	entries[*entry_size] = 0;
	return (entries);
}

int	alloc_arr(char **tmp, int max_str)
{
	*tmp = (char *)malloc(sizeof(char) * (max_str + 1));
	if (*tmp == 0)
		return (0);
	(*tmp)[max_str] = 0;
	return (1);
}

t_entry	*initialize_entry(unsigned int *key, char ***val)
{
	t_entry	*entry_pt;

	entry_pt = (t_entry *)malloc(sizeof(t_entry));
	entry_pt->key = *key;
	entry_pt->val = *val;
	return (entry_pt);
}

int	parse(unsigned int *key, char ***val, char *tmp)
{
	unsigned int	num;

	if (ft_atoi(tmp) > -1)
	{
		num = (unsigned int)ft_atoi(tmp);
		*key = num;
		while (*tmp != ':')
			tmp++;
		tmp++;
		*val = ft_split(tmp, " \n");
		return (1);
	}
	return (0);
}
