/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main2.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: inkim <inkim@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/20 09:42:12 by inkim             #+#    #+#             */
/*   Updated: 2022/02/20 18:40:07 by inkim            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include "t_entry.h"

int			ft_atoi(char *str);
char		**ft_split(char *str, char *charset);
void		ft_putnbr(unsigned int n);
void		join_n_print(char	**buf, int	space);
void		convert(unsigned int	num, int	scale,
				t_entry	**entries, int *printed);
int			search(t_entry	**entries, unsigned int	key, char	***buf);
int			check_arg_num(int argc);
long long	check_key(int argc, char **argv);
int			set_fd(char *file_name, int *fd);
long long	check_arg(int argc, char **argv);
int			close_fd(int fd);
int			find_zero(int fd, char *tmp);
int			print_zero(int argc, char **argv, int col_len);
int			set_lengths(char *file_name, int *entry_size, int *max_str);
t_entry		**alloc_entry(char *file_name, int *entry_size, int *max_str);
int			alloc_arr(char **tmp, int max_str);
t_entry		*initialize_entry(unsigned int *key, char ***val);
int			parse(unsigned int *key, char ***val, char *tmp);
void		read_parse(int fd, char **val, char *tmp, t_entry **entry_arr);
int			fill_entry(char *file_name,
				t_entry **entry_arr, int *max_str, char **val);
int			set_entry(char *file_name, t_entry **entry_arr, int *max_str);
void		free_entry(t_entry **entry_arr);
t_entry		**get_entry(int argc, char **argv, int *entry_size, int *max_len);
int			init_arg(int argc, char **argv, long long *input);
int			main(int argc, char**argv);
void		get_file_name(int argc, char **argv, char *name);

long long	check_key(int argc, char **argv)
{
	int			i;
	long long	nbr;

	nbr = 0;
	i = 0;
	if (argc == 3)
		argv += 2;
	else
		argv += 1;
	while ((*argv)[i] != 0)
	{
		if (!(48 <= (*argv)[i] && (*argv)[i] <= 57) || i > 10)
			return (-1);
		nbr = nbr * 10 + ((*argv)[i] - 48);
		i++;
	}
	if (nbr > 4294967295)
		return (-1);
	return (nbr);
}
