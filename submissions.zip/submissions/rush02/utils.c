/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunjpar <hyunjpar@42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/20 20:48:30 by hyunjpar          #+#    #+#             */
/*   Updated: 2022/02/20 20:48:32 by hyunjpar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include "t_entry.h"

void	ft_putstr(char *str)
{
	int	len;

	len = 0;
	while (str[len])
		++len;
	write(1, str, len);
}

void	ft_putnbr(unsigned int n)
{
	char	c;

	if (n / 10 > 0)
		ft_putnbr(n / 10);
	c = n % 10 + '0';
	write(1, &c, 1);
}

void	print_entries(t_entry	**entry_ptr)
{
	int	i;
	int	j;

	i = 0;
	while (entry_ptr[i])
	{
		j = 0;
		ft_putnbr(entry_ptr[i]->key);
		write(1, " ", 1);
		while (entry_ptr[i]->val[j])
		{
			ft_putstr(entry_ptr[i]->val[j]);
			write(1, " ", 1);
			j++;
		}
		i++;
	}
}
