#include <unistd.h>

int	choose_char(int i, int j, int rows, int cols)
{
	if (i == 0)
	{
		if (j == 0)
			return (1);
		if (j == cols - 1)
			return (2);
		return (5);
	}
	if (i == rows - 1)
	{
		if (j == 0)
			return (3);
		if (j == cols - 1)
			return (4);
		return (8);
	}
	if (j == 0)
		return (6);
	if (j == cols - 1)
		return (7);
	return (0);
}

void	ft_putchar(char	c)
{
	write(1, &c, 1);
}

void	rush_base(char	*chrs, int	rows, int cols)
{
	int	i;
	int	j;

	i = 0;
	while (i < rows)
	{
		j = 0;
		while (j < cols)
		{
			ft_putchar(chrs[choose_char(i, j, rows, cols)]);
			j += 1;
		}
		ft_putchar('\n');
		i += 1;
	}
}
