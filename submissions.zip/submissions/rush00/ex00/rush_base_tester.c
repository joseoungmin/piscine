#include <stdlib.h>
#include <string.h>
#include <stdio.h>

extern void rush_base(char *chrs, int rows, int cols);

int main(int argc, char **argv) {
	char chrs[20];
	int rows, cols;

	chrs[0] = ' ';
	strncpy((char*)(chrs+1), argv[1], 8);
	rows = atoi(argv[2]);
	cols = atoi(argv[3]);

	printf("%d %d\n", rows, cols);
	//rush_base(chrs, rows, cols);
}
