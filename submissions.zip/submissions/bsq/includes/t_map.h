/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   t_map.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyebpark <hyebpark@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/24 11:56:10 by hyebpark          #+#    #+#             */
/*   Updated: 2022/02/24 11:56:28 by hyebpark         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef T_MAP_H
# define T_MAP_H

# include "t_array.h"

typedef struct s_map {
	int		rows;
	int		cols;
	int		**data;
	char	c_empty;
	char	c_obstacle;
	char	c_full;
}	t_map;

t_map	*init_map(void);
int		set_map(t_map *map);
int		append_map(t_map *map, t_array *array, int row_idx_to_append);
void	free_map(t_map *map);
void	print_map(t_map *map);

#endif
