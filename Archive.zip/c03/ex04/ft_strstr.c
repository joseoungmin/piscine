/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/18 13:57:28 by seojo             #+#    #+#             */
/*   Updated: 2022/05/03 09:58:30 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{
	int	i;
	int	j;
	int	count;

	i = 0;
	if (*to_find == '\0')
		return (str);
	while (str[i])
	{
		if (str[i] == to_find[j])
		{	
			j = 0;
			count = 0;
			while (to_find[j])
			{
				if (str[i + j] != to_find[j])
					count = 1;
				j++;
			}
			if (count == 0)
				return (str + i);
		}
		i++;
	}
	return (0);
}
