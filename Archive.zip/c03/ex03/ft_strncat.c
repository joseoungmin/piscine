/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/18 08:36:29 by seojo             #+#    #+#             */
/*   Updated: 2022/04/25 18:30:35 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned char	*result;

	result = (unsigned char *) dest;
	while (*dest)
		dest++;
	while (nb-- && *src)
		*dest++ = *src++;
	*dest = '\0';
	return (result);
}
