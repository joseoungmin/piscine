/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_show_tab.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/27 21:04:14 by seojo             #+#    #+#             */
/*   Updated: 2022/04/28 16:22:24 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_stock_str.h"
#include <unistd.h>

void	ft_putstr(char *arr)
{
	while (*arr)
		write(1, arr++, 1);
}

void	number_received(int nb)
{
	int	nb_arr[11];
	int	i;

	i = 0;
	while (nb > 0)
	{
		nb_arr[i] = (nb % 10) + '0';
		nb /= 10;
		i++;
	}
	i--;
	while (i >= 0)
		write (1, &nb_arr[i--], 1);
}

void	ft_putnbr(int nb)
{
	int	i;

	i = 0;
	if (nb == 0)
	{
		write (1, "0", 1);
		return ;
	}
	if (nb == -2147483648)
	{
		write (1, "-2147483648\n", 12);
		return ;
	}
	if (nb < 0)
	{
		nb *= -1;
		write (1, "-", 1);
	}
	number_received(nb);
}

void	ft_show_tab(struct s_stock_str *par)
{
	int	i;

	i = 0;
	while (par[i].str != 0)
	{
		ft_putstr(par[i].str);
		write(1, "\n", 1);
		ft_putnbr(par[i].size);
		write(1, "\n", 1);
		ft_putstr(par[i].str);
		write(1, "\n", 1);
		i++;
	}
}
