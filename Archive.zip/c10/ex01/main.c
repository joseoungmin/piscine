/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/03 18:50:35 by seojo             #+#    #+#             */
/*   Updated: 2022/05/04 09:39:31 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <libgen.h>
#include <unistd.h>

void	ft_putstr(char *str)
{
	while (*str)
		write(1, str++, 1);
}

void	print_error(char *name, char *str)
{
	ft_putstr(basename(name));
	ft_putstr(": ");
	ft_putstr(str);
	ft_putstr(": ");
	ft_putstr(strerror(errno));
	ft_putstr("\n");
	errno = 0;
}

void	display_file(int op, char *name, char *file)
{
	long	size;
	char	buf;

	size = read(op, &buf, 1);
	while (size)
	{
		if (errno)
		{
			print_error(name, file);
			return ;
		}
		write(1, &buf, size);
	}
}

void	ft_inout(void)
{
	char	buf;

	while (read(0, &buf, 1))
		write(1, &buf, 1);
}

int main(int argc, char **argv)
{
	int		op;
	int		i;
	char	buf;

	i = 1;	
	op = open(argv[1], O_RDONLY);
	if (argc == 1)
		ft_inout();
	while (i < argc)
	{
		if (argv[i][0] == '-' && argv[i][1] == '\0')
			ft_inout();
		else if ((op = open(argv[i], O_DIRECTORY)) == -1)
		{
			if ((op = open(argv[i], O_RDONLY)) == -1)
				print_error(argv[0], argv[i]);
			else
				while (read(op, &buf, 1))
					write(1, &buf, 1);
		}
		else
			display_file(op, argv[0], argv[i]);
		i++;
	}
	close(op);
}
