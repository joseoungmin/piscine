/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/03 08:09:05 by seojo             #+#    #+#             */
/*   Updated: 2022/05/03 16:13:26 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	main(int argc, char **argv)
{
	int		fp;
	char	buf;

	if (argc == 1)
		write (1, "File name missing.\n", 19);
	else if (argc > 2)
		write (1, "Too many arguments.\n", 20);
	else
	{
		fp = open(argv[1], O_RDONLY);
		if (fp == -1)
			write (1, "Cannot read file.", 17);
		else
		{
			while (read(fp, &buf, 1))
				ft_putchar(buf);
			close(fp);
		}
	}
}
