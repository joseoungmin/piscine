/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_cobn.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/14 10:48:48 by seojo             #+#    #+#             */
/*   Updated: 2022/05/02 20:54:27 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	repeat_call(int n, char *arr, int i, int size )
{
	if (size == n)
	{
		write(1, arr, n);
		if (arr[0] != 10 - n + '0')
		{
			write(1, ", ", 2);
			return ;
		}
	}
	while (i <= 9)
	{
		arr[size] = i + '0';
		repeat_call(n, arr, i + 1, size + 1);
		i++;
	}
}

void	ft_print_combn(int n)
{
	char	arr[10];

	if (n > 0 && n < 10)
		repeat_call(n, arr, 0, 0);
}
