/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/14 07:05:38 by seojo             #+#    #+#             */
/*   Updated: 2022/05/02 20:35:43 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	putchar(char c)
{
	write(1, &c, 1);
}

void	growing_number(int num1, int num2)
{
	putchar((num1 / 10) + '0');
	putchar((num1 % 10) + '0');
	write (1, " ", 1);
	putchar((num2 / 10) + '0');
	putchar((num2 % 10) + '0');
	if (num1 + num2 != 197)
		write (1, ", ", 2);
}

void	ft_print_comb2(void)
{
	int	num1;
	int	num2;

	num1 = -1;
	while (++num1 <= 98)
	{
		num2 = num1;
		while (++num2 <= 99)
			growing_number(num1, num2);
	}
}
