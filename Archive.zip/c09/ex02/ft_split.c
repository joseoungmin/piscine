/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/28 21:36:51 by seojo             #+#    #+#             */
/*   Updated: 2022/04/30 10:29:49 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	yes_or_no(char c, char *cs)
{
	int	i;

	if (c == '\0')
		return (1);
	i = -1;
	while (cs[++i])
		if (c == cs[i])
			return (1);
	return (0);
}

void	word_copy(char *res, char *str, int size)
{
	int	i;

	i = -1;
	while (++i < size)
		res[i] = str[i];
	res[i] = '\0';
}

void	split_sub(char *str, char *charset, char **res)
{
	int	j;
	int	i;
	int	wlen;

	j = 0;
	i = 0;
	while (str[i])
	{
		if (yes_or_no(str[i], charset))
			i++;
		else
		{
			wlen = 0;
			while (!yes_or_no(str[i + wlen], charset))
				wlen++;
			res[j] = (char *)malloc(sizeof(char) * (wlen + 1));
			word_copy(res[j], &str[i], wlen);
			i += wlen;
			j++;
		}
	}
	res[j] = 0;
}

char	**ft_split(char *str, char *charset)
{
	int		i;
	int		words;
	char	**res;

	words = 0;
	i = -1;
	while (str[++i])
		if (!yes_or_no(str[i], charset) && yes_or_no(str[i + 1], charset))
			words++;
	res = (char **)malloc(sizeof(char *) * (words + 1));
	split_sub(str, charset, res);
	return (res);
}
