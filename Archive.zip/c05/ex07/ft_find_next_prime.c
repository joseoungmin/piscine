/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/23 21:42:29 by seojo             #+#    #+#             */
/*   Updated: 2022/04/25 11:53:10 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	is_prime(int nb)
{
	int	i;
	int	cnt;

	i = 2;
	cnt = 0;
	if (nb == 1 || nb == 0)
		return (0);
	while (i <= nb / i)
	{
		if (nb % i == 0)
			return (0);
		i++;
	}
	return (1);
}

int	ft_find_next_prime(int nb)
{	
	if (nb <= 2)
		return (2);
	while (1)
	{
		if (!(nb % 2))
			nb++;
		if (is_prime(nb) == 1)
			return (nb);
		nb++;
	}
}
