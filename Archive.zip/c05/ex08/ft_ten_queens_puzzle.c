/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   queen.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/24 08:22:31 by seojo             #+#    #+#             */
/*   Updated: 2022/05/03 10:56:44 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_abs(int num)
{
	if (num > 0)
		return (num);
	else
		return (num * -1);
}

int	promising(int cdx, char *x)
{
	int	y;

	y = 0;
	while (y < cdx)
	{
		if (x[cdx] == x[y] || cdx - y == ft_abs(x[cdx] - x[y]))
			return (0);
		y++;
	}
	return (1);
}

void	tenqueen(int cdx, char *x, int *count)
{
	int	j;

	j = 0;
	if (cdx == 10)
	{
		write(1, x, 10);
		write(1, "\n", 1);
		++*count;
		return ;
	}
	while (j < 10)
	{
		x[cdx] = j + '0';
		if (promising(cdx, x))
			tenqueen(cdx + 1, x, count);
		j++;
	}
}

int	ft_ten_queens_puzzle(void)
{
	char	x[11];
	int		count;

	count = 0;
	tenqueen(0, x, &count);
	return (count);
}
