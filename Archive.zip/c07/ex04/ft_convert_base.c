/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/26 07:55:15 by seojo             #+#    #+#             */
/*   Updated: 2022/04/26 21:17:29 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		dothis(long long nb, int len);
void	ft_putnbr(long long nb, char *base, int len, char *result);

int	check_base(char *base)
{
	int	i;
	int	j;

	i = -1;
	while (base[++i])
	{
		if (base[i] == '+' || base[i] == '-' || \
				(9 <= base[i] && base[i] <= 13) || base[i] == 32)
			return (-1);
		j = i;
		while (base[++j])
			if (base[i] == base[j])
				return (-1);
	}
	return (i);
}

int	white_pass(char *str, int *sign)
{
	int	i;

	i = 0;
	while ((9 <= str[i] && str[i] <= 13) || str[i] == 32)
		i++;
	while (str[i] == '+' || str[i] == '-')
	{
		if (str[i] == '-')
			*sign *= -1;
		i++;
	}
	return (i);
}

int	ft_find_base(char *base, char c)
{
	int	i;

	i = 0;
	while (base[i])
	{
		if (base[i] == c)
			return (i);
		i++;
	}
	return (-1);
}

int	ft_atoi(char *str, int size, char *base)
{
	int	i;
	int	j;
	int	sign;
	int	result;

	sign = 1;
	result = 0;
	i = white_pass(str, &sign);
	while (str[i])
	{
		j = ft_find_base(base, str[i]);
		if (j >= 0)
			result = (result * size) + j;
		else
			break ;
		i++;
	}
	return (result * sign);
}

char	*ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	int			size_from;
	int			size_to;
	int			length;
	char		*result;
	long long	base_ten;

	size_from = check_base(base_from);
	size_to = check_base(base_to);
	if (size_from < 2 || size_to < 2)
		return (0);
	base_ten = ft_atoi(nbr, size_from, base_from);
	length = dothis(base_ten, size_to);
	if (base_ten < 0)
		length++;
	result = (char *)malloc(sizeof(char) * (length + 1));
	ft_putnbr(base_ten, base_to, size_to, result);
	return (result);
}
