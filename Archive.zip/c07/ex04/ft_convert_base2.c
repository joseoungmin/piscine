/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/26 16:32:07 by seojo             #+#    #+#             */
/*   Updated: 2022/04/26 21:17:54 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	dothis(long long nb, int len)
{
	if (nb < len)
		return (1);
	return (1 + dothis(nb / len, len));
}

void	ft_putnbr(long long nb, char *base, int len, char *result)
{
	int	length;
	int	sign;

	sign = 0;
	length = dothis(nb, len);
	if (nb < 0)
	{
		nb *= -1;
		result[0] = '-';
		sign = 1;
		length = dothis(nb, len);
		length++;
	}
	result[length] = 0;
	while (--length >= sign)
	{
		result[length] = base[nb % len];
		nb /= len;
	}
}
