/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/25 08:14:21 by seojo             #+#    #+#             */
/*   Updated: 2022/04/26 21:18:31 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int			*arr;
	long long	i;

	i = (long long)max - (long long)min;
	if (min >= max)
		return (0);
	arr = (int *)malloc(sizeof(int) * i);
	i = 0;
	while (min < max)
		arr[i++] = min++;
	return (arr);
}
