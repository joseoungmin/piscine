/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/25 07:14:27 by seojo             #+#    #+#             */
/*   Updated: 2022/04/26 20:04:58 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_strdup(char *src)
{
	char	*arr;
	int		len;
	int		i;

	i = -1;
	len = 0;
	while (src[len])
		len++;
	arr = (char *)malloc(sizeof(char) * (len + 1));
	if (!(arr))
		return (NULL);
	while (src[++i])
		arr[i] = src[i];
	arr[i] = '\0';
	return (arr);
}
