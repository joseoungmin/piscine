/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/26 21:19:30 by seojo             #+#    #+#             */
/*   Updated: 2022/04/29 02:00:07 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	yes_or_no(char c, char *cs)
{
	int	i;

	if (c == '\0')
		return (1);
	i = -1;
	while (cs[++i])
		if (c == cs[i])
			return (1);
	return (0);
}

void	word_copy(char *res, char *str, int size)
{
	int	i;

	i = -1;
	while (++i < size)
		res[i] = str[i];
	res[i] = '\0';
}

void	split_sub(char *str, char *charset, char **res)
{
	int	j;
	int	i;
	int	wlen;

	j = 0;
	i = 0;
	while (str[i])
	{
		if (yes_or_no(str[i], charset))
			i++;
		else
		{
			wlen = 0;
			while (!yes_or_no(str[i + wlen], charset))
				wlen++;
			res[j] = (char *)malloc(sizeof(char) * (wlen + 1));
			word_copy(res[j], &str[i], wlen);
			i += wlen;
			j++;
		}
	}
	res[j] = 0;
}

char	**ft_split(char *str, char *charset)
{
	int		i;
	int		words;
	char	**res;

	words = 0;
	i = -1;
	while (str[++i])
		if (!yes_or_no(str[i], charset) && yes_or_no(str[i + 1], charset))
			words++;
	res = (char **)malloc(sizeof(char *) * (words + 1));
	split_sub(str, charset, res);
	return (res);
}

#include<stdio.h>
int main()
{
	printf("\n----ex05----\n");
	char **str_arr;
	int i;
	char arr[100] = "Hello World My\tname\nis jiyonpar";
	printf("< test 1 >  일반적 케이스 1\n");
	str_arr = ft_split(arr, " \n");
	for(i=0;str_arr[i] != 0; i++)
		printf("arr[%d] : %s\n", i, str_arr[i]);
	printf("\n");
	for(i=0;str_arr[i] != 0; i++)
	printf("< test 2 >  일반적 케이스 2\n");
	str_arr = ft_split("Hello World My\tname\nis jiyonpar"," World");
	for(i=0;str_arr[i] != 0; i++)
		printf("arr[%d] : %s\n", i, str_arr[i]);
	printf("\n");
	for(i=0;str_arr[i] != 0; i++)
	printf("< test 3 >  구분자가 없는 경우\n");
	str_arr = ft_split("Hello World My\tname\nis jiyonpar","");
	for(i=0;str_arr[i] != 0; i++)
		printf("arr[%d] : %s\n", i, str_arr[i]);
	printf("\n");
	for(i=0;str_arr[i] != 0; i++)
	printf("< test 4 >  문자열이 없고 구분자가 있는 경우\n");
	str_arr = ft_split(""," ");
	for(i=0;str_arr[i] != 0; i++)
		printf("arr[%d] : %s\n", i, str_arr[i]);
	printf("\n");
	for(i=0;str_arr[i] != 0; i++)
	printf("< test 5 >  구분자가 문자열에 포함되어있지 않은 경우\n");
	str_arr = ft_split("Hello World My\tname\nis jiyonpar","123");
	for(i=0;str_arr[i] != 0; i++)
		printf("arr[%d] : %s\n", i, str_arr[i]);
	printf("\n");
}

