/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/25 19:47:02 by seojo             #+#    #+#             */
/*   Updated: 2022/04/27 10:32:05 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *arr)
{
	int	i;

	i = 0;
	while (*arr++)
		i++;
	return (i);
}

void	ft_strcat(char *dest, char *src)
{
	while (*dest)
		dest++;
	while (*src)
		*dest++ = *src++;
	*dest = 0;
}

int	ft_sentense_len(char **strs, int size)
{
	int	i;
	int	j;
	int	cnt;

	i = 0;
	j = 0;
	cnt = 0;
	while (i != size)
	{
		if (strs[i][j] == 0)
		{
			j = 0;
			i++;
		}
		j++;
		cnt++;
	}
	return (cnt);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		i;
	int		str_l;
	int		sep_l;
	char	*string;

	str_l = ft_sentense_len(strs, size);
	sep_l = ft_strlen(sep);
	if (size == 0)
	{
		string = (char *)malloc(sizeof(char));
		*string = 0;
		return (string);
	}
	string = (char *)malloc(sizeof(char) * (str_l + ((size - 1) * sep_l) + 1));
	if (string == NULL)
		return (0);
	*string = 0;
	i = -1;
	while (++i < size)
	{
		ft_strcat(string, strs[i]);
		if (i < size - 1)
			ft_strcat(string, sep);
	}
	return (string);
}
/*
#include <stdio.h>
int main()
{
	    printf("-------ex03-------\n\n");
	char *ex03_arr1;
    char *ex03_arr2;
    char *ex03_arr3;
	char *ex03_str[5];

	ex03_str[0] = "hello";
	ex03_str[1] = "my";
	ex03_str[2] = "name";
	ex03_str[3] = "is";
	ex03_str[4] = "hunpark!";
	ex03_arr1 = ft_strjoin(5, ex03_str, " ");
    ex03_arr2 = ft_strjoin(5, ex03_str, ".");
    ex03_arr3 = ft_strjoin(5, ex03_str, "-");
	printf("%s\n\n", ex03_arr1);
    printf("%s\n\n", ex03_arr2);
	printf("%s\n\n", ex03_arr3);
    free(ex03_arr1);
    free(ex03_arr2);
}*/
