/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/22 19:19:03 by seojo             #+#    #+#             */
/*   Updated: 2022/04/22 22:02:41 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strcmp(char *s1, char *s2)
{
	while ((*s1 || *s2) && *s1 == *s2)
	{
		s1++;
		s2++;
	}
	return (*s1 - *s2);
}

void	putstr(char *arr)
{
	int	i;

	i = 0;
	while (arr[i])
		write(1, &arr[i++], 1);
	write(1, "\n", 1);
}

int	main(int argc, char **argv)
{
	int		i;
	int		size;
	char	*temp;

	i = argc - 1;
	size = argc - 1;
	while (i--)
	{
		size = argc - 1;
		while (size > 1)
		{
			if (ft_strcmp(argv[size], argv[size - 1]) < 0)
			{
				temp = argv[size];
				argv[size] = argv[size - 1];
				argv[size - 1] = temp;
			}
			size--;
		}
	}
	i = 1;
	while (i < argc)
		putstr(argv[i++]);
	return (0);
}
