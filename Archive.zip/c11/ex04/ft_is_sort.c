/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/30 20:45:37 by seojo             #+#    #+#             */
/*   Updated: 2022/04/30 22:27:57 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_down(int *tab, int i, int length, int (*f)(int, int))
{
	while (++i < length - 1)
		if ((*f)(tab[i], tab[i + 1]) > 0)
			return (0);
	return (1);
}

int	ft_is_up(int *tab, int i, int length, int (*f)(int, int))
{
	while (++i < length - 1)
		if ((*f)(tab[i], tab[i + 1]) < 0)
			return (0);
	return (1);
}

int	ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	if (ft_is_down(tab, -1, length, f) || (ft_is_up(tab, -1, length, f)))
		return (1);
	else
		return (0);
}
