/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/30 15:57:18 by seojo             #+#    #+#             */
/*   Updated: 2022/04/30 17:55:54 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_map(int *tab, int length, int (*f)(int))
{
	int	i;
	int	*num_arr;

	i = -1;
	num_arr = (int *)malloc(sizeof(int) * length);
	while (++i < length)
		num_arr[i] = (*f)(tab[i]);
	return (num_arr);
}
