/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   functions.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/01 09:57:25 by seojo             #+#    #+#             */
/*   Updated: 2022/05/01 16:50:07 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "op.h"

int	ft_strlen(char *c)
{
	int	i;

	i = 0;
	while (c[i])
		i++;
	return (i);
}

void	ft_putchar(char c)
{
	write (1, &c, 1);
}

void	ft_putnbr(int nb)
{
	char	c;

	if (nb == -2147483648)
	{
		write(1, "-2147483648", 11);
		return ;
	}
	if (nb < 0)
	{
		write (1, "-", 1);
		nb = -nb;
	}
	if (nb < 10)
		c = '0' + nb;
	if (nb > 9)
	{
		ft_putnbr(nb / 10);
		c = '0' + nb % 10;
	}
	ft_putchar(c);
}

int	ft_atoi(char *str)
{
	int	i;
	int	m;
	int	nb;

	i = 0;
	m = 1;
	nb = 0;
	while (str[i] == 32 || (9 <= str[i] && str[i] <= 13))
		i++;
	while (str[i] == '-' || str[i] == '+' )
	{
		if (str[i] == '-')
			m *= -1;
		i++;
	}
	while ('0' <= str[i] && str[i] <= '9')
				nb = 10 * nb + str[i++] - '0';
	return (m * nb);
}

int	check_op(char c)
{
	if (c == '+')
		return (0);
	else if (c == '-')
		return (1);
	else if (c == '*')
		return (2);
	else if (c == '/')
		return (3);
	else if (c == '%')
		return (4);
	else
		return (-1);
}
