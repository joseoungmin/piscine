/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/30 22:31:28 by seojo             #+#    #+#             */
/*   Updated: 2022/05/02 04:44:10 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "op.h"

void	result_nb(int num1, int num2, int op)
{
	int	(*f_arr[5])(int, int);
	int	nb;

	f_arr[0] = add;
	f_arr[1] = sub;
	f_arr[2] = mul;
	f_arr[3] = div;
	f_arr[4] = rem;
	nb = (*f_arr[op])(num1, num2);
	ft_putnbr(nb);
	write(1, "\n", 1);
}

int	main(int argc, char **argv)
{
	int	num1;
	int	num2;
	int	op;

	op = check_op(argv[2][0]);
	if (argc != 4)
		return (0);
	if (op == -1 || ft_strlen(argv[2]) != 1)
	{
		write(1, "0\n", 2);
		return (0);
	}
	if (argc == 4 && op != -1)
	{
		num1 = ft_atoi(argv[1]);
		num2 = ft_atoi(argv[3]);
		if (argv[2][0] == '/' && argv[3][0] == '0')
			write(1, "Stop : division by zero\n", 24);
		else if (argv[2][0] == '%' && argv[3][0] == '0')
			write(1, "Stop : modulo by zero\n", 22);
		else
			result_nb(num1, num2, op);
	}
	return (0);
}
