/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   op.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <seojo@student.42seoul.kr>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/01 09:27:10 by seojo             #+#    #+#             */
/*   Updated: 2022/05/01 11:19:08 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef OP_H
# define OP_H

# include <unistd.h>

int		add(int a, int b);
int		sub(int a, int b);
int		mul(int a, int b);
int		div(int a, int b);
int		rem(int a, int b);
int		ft_strlen(char *c);
int		ft_atoi(char *str);
int		check_op(char c);
void	ft_putnbr(int nb);
void	ft_putchar(char c);

#endif
