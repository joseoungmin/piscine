/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/20 11:19:15 by seojo             #+#    #+#             */
/*   Updated: 2022/05/03 10:22:19 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putnbr(long long nb, char *base, int radix)
{
	int	i;
	int	nb_arr[11];

	i = -1;
	if (nb == 0)
	{
		write(1, &base[0], 1);
		return ;
	}
	if (nb < 0)
	{
		nb *= -1;
		write (1, "-", 1);
	}
	while (nb > 0)
	{
		nb_arr[++i] = base[nb % radix];
		nb /= radix;
	}
	while (i >= 0)
		write (1, &nb_arr[i--], 1);
}

int	base_check(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i])
	{
		if (base[i] == '+' || base[i] == '-')
			return (-1);
		j = i + 1;
		while (base[j])
		{
			if (base[i] == base[j])
				return (-1);
			j++;
		}
		i++;
	}
	return (i);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int			base_len;
	long long	nb;

	nb = (long long) nbr;
	radix = base_check(base);
	if (base_len <= 1)
		return ;
	ft_putnbr(nb, base, radix);
}
