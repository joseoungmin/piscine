/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/20 14:06:37 by seojo             #+#    #+#             */
/*   Updated: 2022/04/26 12:18:34 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	check_base(char *base)
{
	int	i;
	int	j;

	i = -1;
	while (base[++i])
	{
		if (base[i] == '+' || base[i] == '-' || \
				(9 <= base[i] && base[i] <= 13) || base[i] == 32)
			return (-1);
		j = i;
		while (base[++j])
		{
			if (base[i] == base[j])
				return (-1);
		}
	}
	return (i);
}

int	pass(char *str)
{
	int	i;
	int	m;

	m = 1;
	i = 0;
	while ((9 <= str[i] && str[i] <= 13) || str[i] == 32)
		i++;
	while (str[i] == '+' || str[i] == '-')
	{
		if (str[i] == '-')
			m = -m;
		i++;
	}
	return (i * m);
}

int	ft_find_base(char *base, char c)
{
	int	i;

	i = 0;
	while (base[i])
	{
		if (base[i] == c)
			return (i);
		i++;
	}
	return (-1);
}

int	ft_atoi(char *str, int size, char *base)
{
	int	i;
	int	j;
	int	m;
	int	result;

	m = 1;
	result = 0;
	i = pass(str);
	if (i < 0)
	{
		i *= -1;
		m = -1;
	}
	while (str[i])
	{
		j = ft_find_base(base, str[i]);
		if (j >= 0)
			result = (result * size) + j;
		else
			break ;
		i++;
	}
	return (result * m);
}

int	ft_atoi_base(char *str, char *base)
{
	int	size;

	size = check_base(base);
	if (size <= 1)
		return (0);
	return (ft_atoi(str, size, base));
}
/*
#include <stdio.h>
int main()
{
	//ex05
	printf("------ ex05 ------\n\n");
	char ex05_str1[] = " \n -+-++-+2147483648";
	char ex05_str2[] = "   ---+AABCDESSEZ";
	char ex05_str3[] = "   ++136667";
	char ex05_str4[] = "   -----+-+!!@@#..<";
	char ex05_str5[] = "  \n \tatoi12-+123base";

	printf("-2147483648\n");
	printf("%d\n\n", ft_atoi_base(ex05_str1, "0123456789"));

	printf("0\n");
	printf("%d\n\n", ft_atoi_base(ex05_str1, ""));

	printf("-67174\n");
	printf("%d\n\n", ft_atoi_base(ex05_str2, "ABCDES"));

	printf("-1\n");
	printf("%d\n\n", ft_atoi_base(ex05_str2, "ABZ"));

	printf("0\n");
	printf("%d\n\n", ft_atoi_base(ex05_str3, "A-+"));

	printf("12347\n");
	printf("%d\n\n", ft_atoi_base(ex05_str3, "3405816"));

	printf("1126397\n");
	printf("%d\n\n", ft_atoi_base(ex05_str4, "!@#$%^&*()~?><'."));

	printf("27\n");
	printf("%d\n\n", ft_atoi_base(ex05_str5, "atoi"));
}*/
