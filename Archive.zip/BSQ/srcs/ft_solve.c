/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_solve.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyebpark <hyebpark@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/24 11:55:18 by hyebpark          #+#    #+#             */
/*   Updated: 2022/05/03 17:25:16 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include "t_map.h"

int	min_size(int a, int b, int c)
{
	int	min;

	if (a <= b && a <= c)
		min = a;
	else if (b <= c)
		min = b;
	else
		min = c;
	return (min);
}

void	draw_map(int rows, int cols, int size, t_map *map)
{
	int	i;
	int	j;

	i = 0;
	while (i < map->rows)
	{
		j = 0;
		while (j < map->cols)
		{
			if (i <= rows && i > rows - size && j <= cols && j > cols - size)
				write(1, &(map->c_full), 1);
			else if (map->data[i][j] == 0)
				write(1, &(map->c_obstacle), 1);
			else
				write(1, &(map->c_empty), 1);
			j++;
		}
		write (1, "\n", 1);
		i++;
	}
}

void	find_max_val(int i, int j, t_map *map)
{
	int	max_size;
	int	max_row;
	int	max_col;

	max_size = 0;
	max_row = 0;
	max_col = 0;
	while (i < map->rows)
	{
		j = 0;
		while (j < map->cols)
		{
			if (max_size < map->data[i][j])
			{
				max_size = map->data[i][j];
				max_row = i;
				max_col = j;
			}
			j++;
		}
		i++;
	}
	draw_map(max_row, max_col, max_size, map);
}

void	solve(int i, int j, t_map *map)
{
	int	a;
	int	b;
	int	c;

	while (++i < map -> rows)
	{
		j = 0;
		while (++j < map -> cols)
		{
			if (map->data[i][j] != 0)
			{
				a = map->data[i - 1][j - 1];
				b = map->data[i - 1][j];
				c = map->data[i][j - 1];
				map->data[i][j] += min_size(a, b, c);
			}
		}
	}
	find_max_val(0, 0, map);
}
