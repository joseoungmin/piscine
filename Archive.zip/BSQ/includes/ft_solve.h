/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_solve.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyebpark <hyebpark@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/24 11:55:58 by hyebpark          #+#    #+#             */
/*   Updated: 2022/02/24 11:56:00 by hyebpark         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_SOLVE_H
# define FT_SOLVE_H
# include "t_map.h"

int		ft_min_num(int a, int b, int c);
void	draw_map(int rows, int cols, int size, t_map *digit_map);
void	solve(int i, int j, t_map *digit_map);
#endif
