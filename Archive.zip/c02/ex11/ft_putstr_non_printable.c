/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/16 16:23:35 by seojo             #+#    #+#             */
/*   Updated: 2022/05/03 09:42:19 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr_non_printable(char *str)
{
	unsigned char	cur;
	const char		*base_16;

	base_16 = "0123456789abcdef";
	while (*str)
	{
		cur = *str++;
		if (!(cur >= 32 && cur < 127))
		{
			write(1, "\\", 1);
			write(1, base_16 + (cur >> 4), 1);
			write(1, base_16 + (cur & 15), 1);
		}
		else
			write(1, &cur, 1);
	}
}
