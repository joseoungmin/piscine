/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/16 07:37:59 by seojo             #+#    #+#             */
/*   Updated: 2022/04/19 08:49:43 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	is_al(char c)
{
	if (c >= 'a' && c <= 'z')
		return (1);
	else if (c >= 'A' && c <= 'Z')
		return (2);
	else if (c >= '0' && c <= '9')
		return (3);
	else
		return (0);
}

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 1;
	if (is_al(str[0]) == 1)
		str[0] -= 32;
	while (str[i])
	{
		if (is_al(str[i]) == 2 && is_al(str[i - 1]) != 0)
			str[i] += 32;
		else if (is_al(str[i]) == 1 && is_al(str[i - 1]) == 0)
			str[i] -= 32;
		i++;
	}
	return (str);
}
