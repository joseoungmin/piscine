/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pirnt_memory.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seojo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/17 10:50:50 by seojo             #+#    #+#             */
/*   Updated: 2022/04/18 21:39:25 by seojo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	field_1(unsigned long addr)
{
	int				i;
	unsigned long	offset;
	const char		*arr_16;

	i = 8;
	offset = addr;
	arr_16 = "0123456789abcdef";
	while (--i >= 0)
	{
		write(1, arr_16 + (((offset >> (i * 8)) >> 4) & 15), 1);
		write(1, arr_16 + (offset >> (i * 8) & 15), 1);
	}
	write(1, ": ", 2);
}

void	field_2(char *addr, int len)
{
	int			i;
	const char	*arr_16;

	i = 0;
	arr_16 = "0123456789abcdef";
	while (i < 16)
	{
		if (i < len)
		{
			write(1, arr_16 + ((unsigned char)addr[i] / 16), 1);
			write(1, arr_16 + ((unsigned char)addr[i] % 16), 1);
		}
		else
			write(1, "  ", 2);
		if (i % 2 == 1)
			write(1, " ", 1);
		i++;
	}
}

void	field_3(char *addr, int size)
{
	int	i;

	i = 0;
	while (i < 16)
	{
		if (i >= size)
			break ;
		if (addr[i] < 32 || addr[i] == 127)
			write(1, ".", 1);
		else
			write(1, &addr[i], 1);
		i++;
	}
	write(1, "\n", 1);
}

void	*ft_print_memory(void *addr, unsigned int size)
{
	int	num;
	int	s;

	s = (int) size;
	num = 0;
	while (s > 0)
	{	
		field_1((unsigned long) addr + num);
		field_2((char *) addr + num, s);
		field_3((char *)addr + num, s);
		s -= 16;
		num += 16;
	}
	return (addr);
}
